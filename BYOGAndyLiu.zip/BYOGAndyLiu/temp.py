if "spawn" not in game.selected_ship.attack_3.type:
    attack_3_damage_display_bar = Bar(WIN_W / 4 + 300, WIN_H / 4, ORANGE, 1, "Damage", length=60, height=12,
                                     screen="tech_tree_popup")
    if "laser" in game.selected_ship.attack_3.type:
        attack_3_firerate_display_bar.length = math.sqrt(game.selected_ship.attack_3.firerate) * 6
        attack_3_damage_display_bar.length = math.sqrt(float(game.selected_ship.attack_3.type[5:-1])) * 8
    else:
        attack_3_firerate_display_bar.length = math.sqrt(
            60 / (60 / game.selected_ship.attack_3.firerate + game.selected_ship.attack_3.cooldown)) * 6
        attack_3_damage_display_bar.length = game.selected_ship.attack_3.bullet.damage * 2
    attack_3_firerate_display_bar = Bar(WIN_W / 4 + 300, WIN_H / 4 + WIN_H / 40, ORANGE, 1, "Firerate", length=60,
                                       height=12, screen="tech_tree_popup")

    attack_3_ammo_display_bar = Bar(WIN_W / 4 + 300, WIN_H / 4 + 2 * WIN_H / 40, ORANGE, 1,
                                   "Capacity", length=60, height=12,
                                   screen="tech_tree_popup")
    attack_3_ammo_display_bar.length = math.sqrt(game.selected_ship.attack_3.volley) * 3
else:
    attack_3_health_display_bar = Bar(WIN_W / 4 + 300, WIN_H / 4 + WIN_H / 40, ORANGE, 1, "Health", length=60, height=12,
                                     screen="tech_tree_popup")
    attack_3_firerate_display_bar.length = math.sqrt(
        game.selected_ship.attack_3.bullet.health * 3)
    attack_3_damage_display_bar = Bar(WIN_W / 4 + 300, WIN_H / 4 + WIN_H / 40, ORANGE, 1, "Damage", length=60, height=12,
                                     screen="tech_tree_popup")
    if "laser" in game.selected_ship.attack_3.bullet.attack.type:
        attack_3_firerate_display_bar.length = math.sqrt(game.selected_ship.attack_3.bullet.attack.firerate) * 6
        attack_3_damage_display_bar.length = math.sqrt(float(game.selected_ship.attack_3.bullet.attack[5:-1])) * 8
    else:
        attack_3_firerate_display_bar.length = math.sqrt(60 / (
                    60 / game.selected_ship.attack_3.bullet.attack.firerate + game.selected_ship.attack_3.bullet.attack.cooldown)) * 6
        attack_3_damage_display_bar.length = game.selected_ship.attack_3.bullet.attack.bullet.damage * 2
    attack_3_firerate_display_bar = Bar(WIN_W / 4 + 300, WIN_H / 4 + 2 * WIN_H / 40, ORANGE, 1, "Firerate", length=60,
                                       height=12, screen="tech_tree_popup")

    attack_3_ammo_display_bar = Bar(WIN_W / 4 + 300, WIN_H / 4 + 3 * WIN_H / 40, ORANGE, 1,
                                   "Capacity", length=60, height=12,
                                   screen="tech_tree_popup")
    attack_3_ammo_display_bar.length = math.sqrt(game.selected_ship.attack_3.bullet.attack.volley) * 3
    attack_3_max_spawned_display_bar = Bar(WIN_W / 4 + 300, WIN_H / 4 + 4 * WIN_H / 40, ORANGE, 1, "Firerate", length=60,
                                          height=12, screen="tech_tree_popup")
    attack_3_max_spawned_display_bar.length = int(game.selected_ship.attack_3.type[5:-1]) * 10
    bar_group.add(attack_3_health_display_bar, attack_3_max_spawned_display_bar)
bar_group.add(attack_3_damage_display_bar,
              attack_3_firerate_display_bar, attack_3_ammo_display_bar)
