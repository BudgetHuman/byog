import os, sys, math, random
from gamedata import *
os.environ['SDL_VIDEO_CENTERED'] = '1'  # Force static position of screen

class Button(pygame.sprite.Sprite):
    def __init__(self, centerx, centery, width, height, screen=None, image=None, hover_image=None, data=None, text=None):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface((width, height))
        self.width = width
        self.height = height
        self.normal_image = image
        self.hover_image = hover_image
        self.rect = self.image.get_rect()
        self.rect.centerx = centerx
        self.rect.centery = centery
        self.image.fill(GREEN)
        self.clicked = False
        self.activate = False
        self.display = True
        self.screen = screen
        self.data = data
        if text:
            self.text = Text(int(self.rect.height//2), text, WHITE, centerx, centery, 1)
            text_group.add(self.text)
        else:
            self.text = False

    def update(self):
        if self.activate:
            self.activate = False
        if self.display:
            if self.rect.collidepoint(pygame.mouse.get_pos()):
                if self.hover_image:
                    self.image = self.hover_image
                else:
                    self.image = pygame.Surface((self.width, self.height))
                    self.image.fill(BLUE)
                if self.clicked == False and pygame.mouse.get_pressed()[0]:
                    self.clicked = True
                if self.clicked and not pygame.mouse.get_pressed()[0]:
                    self.clicked = False
                    self.activate = True
            else:
                if self.normal_image:
                    self.image = self.normal_image
                else:
                    self.image = pygame.Surface((self.width, self.height))
                    self.image.fill(GREEN)
                if self.clicked:
                    self.clicked = False

class Ship(pygame.sprite.Sprite):
    def __init__(self, ship_type, startx, starty):
        pygame.sprite.Sprite.__init__(self)
        self.type = ship_type
        self.speed = ship_type.speed
        self.width = ship_type.width
        self.height = ship_type.height
        if not self.type.image:
            self.image = pygame.transform.scale(default_image, (self.height, self.width))
        else:
            self.image = pygame.transform.scale(self.type.image, (self.height, self.width))
        self.rect = self.image.get_rect()
        self.rect.centerx = startx
        self.rect.centery = starty
        self.fireclock_1 = 0
        self.alive = True
        self.direction = math.pi/2
        self.ammo_1 = self.type.attack_1.volley
        self.hp_regen_timer = 0
        self.shield_regen_timer = 0
        if self.type.attack_3:
            if "laser" in self.type.attack_1.type:
                self.ammo_1_bar = Bar(15, WIN_H - 80, YELLOW, 1, False)
            else:
                self.ammo_1_bar = Bar(15, WIN_H - 80, YELLOW, self.type.attack_1.volley, False)
            self.ammo_2 = self.type.attack_2.volley
            if "laser" in self.type.attack_2.type:
                self.ammo_2_bar = Bar(15, WIN_H - 55, YELLOW, 1, False)
            else:
                self.ammo_2_bar = Bar(15, WIN_H - 55, YELLOW, self.type.attack_2.volley, False)
            bar_group.add(self.ammo_2_bar)
            self.ammo_3 = self.type.attack_3.volley
            self.fireclock_2 = 0
            if "laser" in self.type.attack_3.type:
                self.ammo_3_bar = Bar(15, WIN_H - 30, YELLOW, 1, False)
            else:
                self.ammo_3_bar = Bar(15, WIN_H - 30, YELLOW, self.type.attack_3.volley, False)
            bar_group.add(self.ammo_3_bar)
            self.fireclock_3 = 0
        elif self.type.attack_2:
            if "laser" in self.type.attack_1.type:
                self.ammo_1_bar = Bar(15, WIN_H - 55, YELLOW, 1, False)
            else:
                self.ammo_1_bar = Bar(15, WIN_H - 55, YELLOW, self.type.attack_1.volley, False)
            self.ammo_2 = self.type.attack_2.volley
            if "laser" in self.type.attack_2.type:
                self.ammo_2_bar = Bar(15, WIN_H - 30, YELLOW, 1, False)
            else:
                self.ammo_2_bar = Bar(15, WIN_H - 30, YELLOW, self.type.attack_2.volley, False)
            bar_group.add(self.ammo_2_bar)
            self.fireclock_2 = 0
        else:
            if "laser" in self.type.attack_1.type:
                self.ammo_1_bar = Bar(15, WIN_H - 30, YELLOW, 1, False)
            else:
                self.ammo_1_bar = Bar(15, WIN_H - 30, YELLOW, self.type.attack_1.volley, False)
        bar_group.add(self.ammo_1_bar)

        self.hp = int(self.type.max_health*(2**(self.type.level-1)))
        self.hp_bar = Bar(WIN_W - 165, WIN_H - 30, RED, 1, True)
        bar_group.add(self.hp_bar)
        if self.type.max_shield:
            self.shield = int(self.type.max_shield*(2**(self.type.level-1)))
            self.shield_bar = Bar(WIN_W - 165, WIN_H - 55, BLUE, 2, True)
            bar_group.add(self.shield_bar)
            self.shield_active = True

    def update(self, camera, screen):
        key = pygame.key.get_pressed()
        if key[pygame.K_w] or key[pygame.K_UP]:
            self.rect.y -= self.speed

        if key[pygame.K_s] or key[pygame.K_DOWN]:
            self.rect.y += self.speed

        if key[pygame.K_a] or key[pygame.K_LEFT]:
            self.rect.x -= self.speed

        if key[pygame.K_d] or key[pygame.K_RIGHT]:
            self.rect.x += self.speed

        if self.rect.left < camera.rect.left:
            self.rect.left = camera.rect.left
        if self.rect.right > camera.rect.right:
            self.rect.right = camera.rect.right
        if self.rect.top < camera.rect.top:
            self.rect.top = camera.rect.top
        if self.rect.bottom > camera.rect.bottom:
            self.rect.bottom = camera.rect.bottom

        if (pygame.mouse.get_pressed(3)[0] and not self.type.attack_1.aim) or (self.type.attack_2 and pygame.mouse.get_pressed(3)[2] and not self.type.attack_2.aim) or (self.type.attack_3 and pygame.key.get_pressed()[pygame.K_SPACE] and not self.type.attack_3.aim):
            mouse_direction = math.atan2(self.rect.centery + WIN_H / 2 - camera.rect.centery - pygame.mouse.get_pos()[1], pygame.mouse.get_pos()[0] - (self.rect.centerx + WIN_W / 2 - camera.rect.centerx))
            if math.fabs(self.direction - mouse_direction) < math.radians(self.type.turn_speed) / 60 or math.fabs(self.direction - mouse_direction) > 2 * math.pi - math.radians(self.type.turn_speed) / 60:
                self.direction = mouse_direction
            else:
                if self.direction >= 0:
                    if mouse_direction > self.direction or mouse_direction < self.direction - math.pi:
                        self.direction += math.radians(self.type.turn_speed) / 120
                    else:
                        self.direction -= math.radians(self.type.turn_speed) / 120
                else:
                    if mouse_direction > self.direction and mouse_direction < self.direction + math.pi:
                        self.direction += math.radians(self.type.turn_speed) / 120
                    else:
                        self.direction -= math.radians(self.type.turn_speed) / 120
        else:
            mouse_direction = math.atan2(self.rect.centery + WIN_H / 2 - camera.rect.centery - pygame.mouse.get_pos()[1], pygame.mouse.get_pos()[0] - (self.rect.centerx + WIN_W / 2 - camera.rect.centerx))
            if math.fabs(self.direction - mouse_direction) < math.radians(self.type.turn_speed) / 60 or math.fabs(self.direction - mouse_direction) > 2 * math.pi - math.radians(self.type.turn_speed) / 60:
                self.direction = mouse_direction
            else:
                if self.direction >= 0:
                    if mouse_direction > self.direction or mouse_direction < self.direction - math.pi:
                        self.direction += math.radians(self.type.turn_speed) / 60
                    else:
                        self.direction -= math.radians(self.type.turn_speed) / 60
                else:
                    if mouse_direction > self.direction and mouse_direction < self.direction + math.pi:
                        self.direction += math.radians(self.type.turn_speed) / 60
                    else:
                        self.direction -= math.radians(self.type.turn_speed) / 60


        if pygame.mouse.get_pressed(3)[0] and (self.fireclock_1 == 0 or "laser" in self.type.attack_1.type) and self.ammo_1 >= 1:
            self.shoot1(camera, screen)
        if "laser" in self.type.attack_1.type:
            if not pygame.mouse.get_pressed(3)[0]:
                self.fireclock_1 = 0
                if self.ammo_1 < self.type.attack_1.volley:
                    self.ammo_1 += 1 / self.type.attack_1.cooldown
                else:
                    self.ammo_1 = self.type.attack_1.volley
        else:
            if self.fireclock_1 <= 1:
                self.fireclock_1 = 0
                if self.ammo_1 < self.type.attack_1.volley:
                    self.ammo_1 += 1 / self.type.attack_1.cooldown
                else:
                    self.ammo_1 = self.type.attack_1.volley
            else:
                self.fireclock_1 -= 1

        if self.type.attack_2:
            if pygame.mouse.get_pressed(3)[2] and (self.fireclock_2 == 0 or "laser" in self.type.attack_2.type) and self.ammo_2 >= 1:
                self.shoot2(camera, screen)
            if "laser" in self.type.attack_2.type:
                if not pygame.mouse.get_pressed(3)[2]:
                    self.fireclock_2 = 0
                    if self.ammo_2 < self.type.attack_2.volley:
                        self.ammo_2 += 1 / self.type.attack_2.cooldown
                    else:
                        self.ammo_2 = self.type.attack_2.volley
            else:
                if self.fireclock_2 <= 1:
                    self.fireclock_2 = 0
                    if self.ammo_2 < self.type.attack_2.volley:
                        self.ammo_2 += 1 / self.type.attack_2.cooldown
                    else:
                        self.ammo_2 = self.type.attack_2.volley
                else:
                    self.fireclock_2 -= 1
            self.ammo_2_bar.length = self.ammo_2 * 150 / self.type.attack_2.volley

        if self.type.attack_3:
            if pygame.key.get_pressed()[pygame.K_SPACE] and (
                    self.fireclock_3 == 0 or "laser" in self.type.attack_3.type) and self.ammo_3 >= 1:
                self.shoot3(camera, screen)
            if "laser" in self.type.attack_3.type:
                if not pygame.mouse.get_pressed(3)[2]:
                    self.fireclock_3 = 0
                    if self.ammo_3 < self.type.attack_3.volley:
                        self.ammo_3 += 1 / self.type.attack_3.cooldown
                    else:
                        self.ammo_3 = self.type.attack_3.volley
            else:
                if self.fireclock_3 <= 1:
                    self.fireclock_3 = 0
                    if self.ammo_3 < self.type.attack_3.volley:
                        self.ammo_3 += 1 / self.type.attack_3.cooldown
                    else:
                        self.ammo_3 = self.type.attack_3.volley
                else:
                    self.fireclock_3 -= 1
            self.ammo_3_bar.length = self.ammo_3 * 150 / self.type.attack_3.volley

        if self.hp_regen_timer > 1:
            self.hp_regen_timer -= 1
        else:
            self.hp_regen_timer = 0

        if self.shield_regen_timer > 1:
            self.shield_regen_timer -= 1
        else:
            self.shield_regen_timer = 0

        if self.hp <= 0:
            self.alive = False

        if self.type.max_shield:
            if self.shield_active:
                self.shield_bar.color = BLUE
                if self.shield <= 0:
                    self.shield = 0
                    self.shield_active = False
            else:
                self.shield_bar.color = LIGHT_BLUE
                if self.shield >= self.type.max_shield*2**(self.type.level-1)/2:
                    self.shield_active = True
            if self.shield < 0:
                self.shield = 0
            if self.shield < self.type.max_shield*2**(self.type.level-1) and self.shield_regen_timer == 0:
                self.shield += self.type.shield_regen*2**(self.type.level-1)
                if self.shield > self.type.max_shield*2**(self.type.level-1):
                    self.shield = self.type.max_shield*2**(self.type.level-1)
        if self.hp < 0:
            self.hp = 0
        if self.hp < self.type.max_health*2**(self.type.level-1) and self.hp_regen_timer == 0:
            self.hp += self.type.health_regen*2**(self.type.level-1)
            if self.hp > self.type.max_health*2**(self.type.level-1):
                self.hp = self.type.max_health*2**(self.type.level-1)
        if self.ammo_1 >= 0:
            self.ammo_1_bar.length = self.ammo_1 * 150 / self.type.attack_1.volley
        else:
            self.ammo_1_bar.length = 0
        if self.type.attack_2:
            if self.ammo_2 >= 0:
                self.ammo_2_bar.length = self.ammo_2 * 150 / self.type.attack_2.volley
            else:
                self.ammo_2_bar.length = 0
        if self.type.attack_3:
            if self.ammo_3 >= 0:
                self.ammo_3_bar.length = self.ammo_3 * 150 / self.type.attack_3.volley
            else:
                self.ammo_3_bar.length = 0
        self.hp_bar.length = self.hp * 150 / (self.type.max_health*2**(self.type.level-1))
        self.hp_bar.text.text = str(round(self.hp, 1))
        if self.type.max_shield:
            self.shield_bar.length = self.shield * 150 / (self.type.max_shield*2**(self.type.level-1))
            self.shield_bar.text.text = str(round(self.shield, 1))

    def shoot1(self, camera, screen):
        if self.type.attack_1.aim:
            direction = math.atan2(self.rect.centery + WIN_H / 2 - camera.rect.centery - pygame.mouse.get_pos()[1],
                                   pygame.mouse.get_pos()[0] - (self.rect.centerx + WIN_W / 2 - camera.rect.centerx))
        else:
            direction = self.direction
        for a in range(self.type.attack_1.shots):
            if "shotgun" in self.type.attack_1.type:
                for a in range(int(self.type.attack_1.type[7:-1])):
                    b = Bullet(self, self.type.attack_1.bullet, direction + math.radians(
                        -self.type.attack_1.spread / 2 + self.type.attack_1.spread * a / (
                                int(self.type.attack_1.type[7:-1]) - 1)) + math.radians(
                        random.randrange(-self.type.attack_1.random_spread, self.type.attack_1.random_spread + 1)), self.type.level)
                    bullet_group.add(b)
            elif "sides" in self.type.attack_1.type:
                if int(self.type.attack_1.type[5:-1]) % 2 == 0:
                    for a in range(int(self.type.attack_1.type[5:-1]) // 2):
                        b = Bullet(self, self.type.attack_1.bullet, direction - math.pi / 2 - math.radians(
                            self.type.attack_1.spread * (a + 1)) + math.radians(
                            random.randrange(-self.type.attack_1.random_spread, self.type.attack_1.random_spread + 1)), self.type.level)
                        bullet_group.add(b)
                        b = Bullet(self, self.type.attack_1.bullet, direction - math.pi / 2 + math.radians(
                            self.type.attack_1.spread * (a + 1)) + math.radians(
                            random.randrange(-self.type.attack_1.random_spread, self.type.attack_1.random_spread + 1)), self.type.level)
                        bullet_group.add(b)
                        b = Bullet(self, self.type.attack_1.bullet, direction + math.pi / 2 - math.radians(
                            self.type.attack_1.spread * (a + 1)) + math.radians(
                            random.randrange(-self.type.attack_1.random_spread, self.type.attack_1.random_spread + 1)), self.type.level)
                        bullet_group.add(b)
                        b = Bullet(self, self.type.attack_1.bullet, direction + math.pi / 2 + math.radians(
                            self.type.attack_1.spread * (a + 1)) + math.radians(
                            random.randrange(-self.type.attack_1.random_spread, self.type.attack_1.random_spread + 1)), self.type.level)
                        bullet_group.add(b)
                else:
                    b = Bullet(self, self.type.attack_1.bullet, direction - math.pi / 2 + math.radians(
                        random.randrange(-self.type.attack_1.random_spread, self.type.attack_1.random_spread + 1)), self.type.level)
                    bullet_group.add(b)
                    b = Bullet(self, self.type.attack_1.bullet, direction + math.pi / 2 + math.radians(
                        random.randrange(-self.type.attack_1.random_spread, self.type.attack_1.random_spread + 1)), self.type.level)
                    bullet_group.add(b)
                    for a in range(int(self.type.attack_1.type[5:-1]) // 2 - 1):
                        b = Bullet(self, self.type.attack_1.bullet, direction - math.pi / 2 - math.radians(
                            self.type.attack_1.spread * (a + 1)) + math.radians(
                            random.randrange(-self.type.attack_1.random_spread, self.type.attack_1.random_spread + 1)), self.type.level)
                        bullet_group.add(b)
                        b = Bullet(self, self.type.attack_1.bullet, direction - math.pi / 2 + math.radians(
                            self.type.attack_1.spread * (a + 1)) + math.radians(
                            random.randrange(-self.type.attack_1.random_spread, self.type.attack_1.random_spread + 1)), self.type.level)
                        bullet_group.add(b)
                        b = Bullet(self, self.type.attack_1.bullet, direction + math.pi / 2 - math.radians(
                            self.type.attack_1.spread * (a + 1)) + math.radians(
                            random.randrange(-self.type.attack_1.random_spread, self.type.attack_1.random_spread + 1)), self.type.level)
                        bullet_group.add(b)
                        b = Bullet(self, self.type.attack_1.bullet, direction + math.pi / 2 + math.radians(
                            self.type.attack_1.spread * (a + 1)) + math.radians(
                            random.randrange(-self.type.attack_1.random_spread, self.type.attack_1.random_spread + 1)), self.type.level)
                        bullet_group.add(b)
            elif "spawn" in self.type.attack_1.type:
                if len(ally_group.sprites()) < int(self.type.attack_1.type[5:-1]):
                    d = 9999
                    for e in enemy_group:
                        new_d = math.hypot(self.rect.centerx - e.rect.centerx, self.rect.centery - e.rect.centery)
                        if new_d < d:
                            d = new_d
                            target = e
                    if d == 9999:
                        target = None
                    a = Ally(self.type.attack_1.bullet, self.rect.center, target, camera, self.type.level)
                    ally_group.add(a)
                    self.fireclock_1 = 60 // self.type.attack_1.firerate
                    self.ammo_1 -= 1

            elif "laser" not in self.type.attack_1.type:
                b = Bullet(self, self.type.attack_1.bullet, direction + math.radians(
                    random.randrange(-self.type.attack_1.random_spread, self.type.attack_1.random_spread + 1)), self.type.level)
                bullet_group.add(b)
            if self.type.attack_1.type == "spiral":
                direction += math.radians(self.type.attack_1.spread)

        if "laser" in self.type.attack_1.type:
            if self.fireclock_1 >= self.type.attack_1.firerate:
                pygame.draw.line(screen, BLUE, (
                    self.rect.centerx + WIN_W / 2 - camera.rect.centerx,
                    self.rect.centery + WIN_H / 2 - camera.rect.centery), (
                                     self.rect.centerx + math.cos(direction) * 1000 + WIN_W / 2 - camera.rect.centerx,
                                     self.rect.centery - math.sin(direction) * 1000 + WIN_H / 2 - camera.rect.centery),
                                 self.type.attack_1.spread)
                for target in enemy_group:
                    target_dist = math.hypot(self.rect.centerx - target.rect.centerx,
                                             self.rect.centery - target.rect.centery)
                    if target.rect.collidepoint((self.rect.centerx + math.cos(direction) * target_dist,
                                                 self.rect.centery - math.sin(direction) * target_dist)):
                        target.hp -= float(self.type.attack_1.type[5:-1])
                self.ammo_1 -= 2
            else:
                pygame.draw.line(screen, LIGHT_BLUE, (
                    self.rect.centerx + WIN_W / 2 - camera.rect.centerx,
                    self.rect.centery + WIN_H / 2 - camera.rect.centery), (
                                     self.rect.centerx + math.cos(direction) * 1000 + WIN_W / 2 - camera.rect.centerx,
                                     self.rect.centery - math.sin(direction) * 1000 + WIN_H / 2 - camera.rect.centery),
                                 int(self.type.attack_1.spread/2 * (self.fireclock_1) / self.type.attack_1.firerate))
                self.ammo_1 -= 1
            self.fireclock_1 += 1
        elif "spawn" not in self.type.attack_1.type:
            self.fireclock_1 = 60 // self.type.attack_1.firerate
            self.ammo_1 -= 1

    def shoot2(self, camera, screen):
        if self.type.attack_2.aim:
            direction = math.atan2(self.rect.centery + WIN_H / 2 - camera.rect.centery - pygame.mouse.get_pos()[1],
                                   pygame.mouse.get_pos()[0] - (self.rect.centerx + WIN_W / 2 - camera.rect.centerx))
        else:
            direction = self.direction
        for a in range(self.type.attack_2.shots):
            if "shotgun" in self.type.attack_2.type:
                for a in range(int(self.type.attack_2.type[7:-1])):
                    b = Bullet(self, self.type.attack_2.bullet, direction + math.radians(
                        -self.type.attack_2.spread / 2 + self.type.attack_2.spread * a / (
                                    int(self.type.attack_2.type[7:-1]) - 1)) + math.radians(
                        random.randrange(-self.type.attack_2.random_spread, self.type.attack_2.random_spread + 1)), self.type.level)
                    bullet_group.add(b)
            elif "sides" in self.type.attack_2.type:
                if int(self.type.attack_2.type[5:-1]) % 2 == 0:
                    for a in range(int(self.type.attack_2.type[5:-1]) // 2):
                        b = Bullet(self, self.type.attack_2.bullet, direction - math.pi / 2 - math.radians(
                            self.type.attack_2.spread * (a + 1)) + math.radians(
                            random.randrange(-self.type.attack_2.random_spread, self.type.attack_2.random_spread + 1)), self.type.level)
                        bullet_group.add(b)
                        b = Bullet(self, self.type.attack_2.bullet, direction - math.pi / 2 + math.radians(
                            self.type.attack_2.spread * (a + 1)) + math.radians(
                            random.randrange(-self.type.attack_2.random_spread, self.type.attack_2.random_spread + 1)), self.type.level)
                        bullet_group.add(b)
                        b = Bullet(self, self.type.attack_2.bullet, direction + math.pi / 2 - math.radians(
                            self.type.attack_2.spread * (a + 1)) + math.radians(
                            random.randrange(-self.type.attack_2.random_spread, self.type.attack_2.random_spread + 1)), self.type.level)
                        bullet_group.add(b)
                        b = Bullet(self, self.type.attack_2.bullet, direction + math.pi / 2 + math.radians(
                            self.type.attack_2.spread * (a + 1)) + math.radians(
                            random.randrange(-self.type.attack_2.random_spread, self.type.attack_2.random_spread + 1)), self.type.level)
                        bullet_group.add(b)
                else:
                    b = Bullet(self, self.type.attack_2.bullet, direction - math.pi / 2 + math.radians(
                        random.randrange(-self.type.attack_2.random_spread, self.type.attack_2.random_spread + 1)), self.type.level)
                    bullet_group.add(b)
                    b = Bullet(self, self.type.attack_2.bullet, direction + math.pi / 2 + math.radians(
                        random.randrange(-self.type.attack_2.random_spread, self.type.attack_2.random_spread + 1)), self.type.level)
                    bullet_group.add(b)
                    for a in range(int(self.type.attack_2.type[5:-1]) // 2 - 1):
                        b = Bullet(self, self.type.attack_2.bullet, direction - math.pi / 2 - math.radians(
                            self.type.attack_2.spread * (a + 1)) + math.radians(
                            random.randrange(-self.type.attack_2.random_spread, self.type.attack_2.random_spread + 1)), self.type.level)
                        bullet_group.add(b)
                        b = Bullet(self, self.type.attack_2.bullet, direction - math.pi / 2 + math.radians(
                            self.type.attack_2.spread * (a + 1)) + math.radians(
                            random.randrange(-self.type.attack_2.random_spread, self.type.attack_2.random_spread + 1)), self.type.level)
                        bullet_group.add(b)
                        b = Bullet(self, self.type.attack_2.bullet, direction + math.pi / 2 - math.radians(
                            self.type.attack_2.spread * (a + 1)) + math.radians(
                            random.randrange(-self.type.attack_2.random_spread, self.type.attack_2.random_spread + 1)), self.type.level)
                        bullet_group.add(b)
                        b = Bullet(self, self.type.attack_2.bullet, direction + math.pi / 2 + math.radians(
                            self.type.attack_2.spread * (a + 1)) + math.radians(
                            random.randrange(-self.type.attack_2.random_spread, self.type.attack_2.random_spread + 1)), self.type.level)
                        bullet_group.add(b)
            elif "spawn" in self.type.attack_2.type:
                if len(ally_group.sprites()) < int(self.type.attack_2.type[5:-1]):
                    d = 9999
                    for e in enemy_group:
                        new_d = math.hypot(self.rect.centerx - e.rect.centerx, self.rect.centery - e.rect.centery)
                        if new_d < d:
                            d = new_d
                            target = e
                    if d == 9999:
                        target = None
                    a = Ally(self.type.attack_2.bullet, self.rect.center, target, camera, self.type.level)
                    ally_group.add(a)
                    self.fireclock_2 = 60 // self.type.attack_2.firerate
                    self.ammo_2 -= 1

            elif "laser" not in self.type.attack_2.type:
                b = Bullet(self, self.type.attack_2.bullet, direction + math.radians(
                    random.randrange(-self.type.attack_2.random_spread, self.type.attack_2.random_spread + 1)), self.type.level)
                bullet_group.add(b)
            if self.type.attack_2.type == "spiral":
                direction += math.radians(self.type.attack_2.spread)

        if "laser" in self.type.attack_2.type:
            if self.fireclock_2 >= self.type.attack_2.firerate:
                pygame.draw.line(screen, BLUE, (
                self.rect.centerx + WIN_W / 2 - camera.rect.centerx, self.rect.centery + WIN_H / 2 - camera.rect.centery), (
                                 self.rect.centerx + math.cos(direction) * 1000 + WIN_W / 2 - camera.rect.centerx,
                                 self.rect.centery - math.sin(direction) * 1000 + WIN_H / 2 - camera.rect.centery),
                                 self.type.attack_2.spread)
                for target in enemy_group:
                    target_dist = math.hypot(self.rect.centerx - target.rect.centerx,
                                             self.rect.centery - target.rect.centery)
                    if target.rect.collidepoint((self.rect.centerx + math.cos(direction) * target_dist,
                                                 self.rect.centery - math.sin(direction) * target_dist)):
                        target.hp -= float(self.type.attack_2.type[5:-1])*(2**(self.type.level-1))
                self.ammo_2 -= 2
            else:
                pygame.draw.line(screen, LIGHT_BLUE, (
                self.rect.centerx + WIN_W / 2 - camera.rect.centerx, self.rect.centery + WIN_H / 2 - camera.rect.centery), (
                                 self.rect.centerx + math.cos(direction) * 1000 + WIN_W / 2 - camera.rect.centerx,
                                 self.rect.centery - math.sin(direction) * 1000 + WIN_H / 2 - camera.rect.centery),
                                 int(self.type.attack_2.spread/2 * (self.fireclock_2) / self.type.attack_2.firerate))
                self.ammo_2 -= 1
            self.fireclock_2 += 1
        elif "spawn" not in self.type.attack_2.type:
            self.fireclock_2 = 60 // self.type.attack_2.firerate
            self.ammo_2 -= 1

    def shoot3(self, camera, screen):
        if self.type.attack_3.aim:
            direction = math.atan2(self.rect.centery + WIN_H / 2 - camera.rect.centery - pygame.mouse.get_pos()[1],
                                   pygame.mouse.get_pos()[0] - (self.rect.centerx + WIN_W / 2 - camera.rect.centerx))
        else:
            direction = self.direction
        for a in range(self.type.attack_3.shots):
            if "shotgun" in self.type.attack_3.type:
                for a in range(int(self.type.attack_3.type[7:-1])):
                    b = Bullet(self, self.type.attack_3.bullet, direction + math.radians(
                        -self.type.attack_3.spread / 2 + self.type.attack_3.spread * a / (
                                    int(self.type.attack_3.type[7:-1]) - 1)) + math.radians(
                        random.randrange(-self.type.attack_3.random_spread, self.type.attack_3.random_spread + 1)), self.type.level)
                    bullet_group.add(b)
            elif "sides" in self.type.attack_3.type:
                if int(self.type.attack_3.type[5:-1]) % 2 == 0:
                    for a in range(int(self.type.attack_3.type[5:-1]) // 2):
                        b = Bullet(self, self.type.attack_3.bullet, direction - math.pi / 2 - math.radians(
                            self.type.attack_3.spread * (a + 1)) + math.radians(
                            random.randrange(-self.type.attack_3.random_spread, self.type.attack_3.random_spread + 1)), self.type.level)
                        bullet_group.add(b)
                        b = Bullet(self, self.type.attack_3.bullet, direction - math.pi / 2 + math.radians(
                            self.type.attack_3.spread * (a + 1)) + math.radians(
                            random.randrange(-self.type.attack_3.random_spread, self.type.attack_3.random_spread + 1)), self.type.level)
                        bullet_group.add(b)
                        b = Bullet(self, self.type.attack_3.bullet, direction + math.pi / 2 - math.radians(
                            self.type.attack_3.spread * (a + 1)) + math.radians(
                            random.randrange(-self.type.attack_3.random_spread, self.type.attack_3.random_spread + 1)), self.type.level)
                        bullet_group.add(b)
                        b = Bullet(self, self.type.attack_3.bullet, direction + math.pi / 2 + math.radians(
                            self.type.attack_3.spread * (a + 1)) + math.radians(
                            random.randrange(-self.type.attack_3.random_spread, self.type.attack_3.random_spread + 1)), self.type.level)
                        bullet_group.add(b)
                else:
                    b = Bullet(self, self.type.attack_3.bullet, direction - math.pi / 2 + math.radians(
                        random.randrange(-self.type.attack_3.random_spread, self.type.attack_3.random_spread + 1)), self.type.level)
                    bullet_group.add(b)
                    b = Bullet(self, self.type.attack_3.bullet, direction + math.pi / 2 + math.radians(
                        random.randrange(-self.type.attack_3.random_spread, self.type.attack_3.random_spread + 1)), self.type.level)
                    bullet_group.add(b)
                    for a in range(int(self.type.attack_3.type[5:-1]) // 2 - 1):
                        b = Bullet(self, self.type.attack_3.bullet, direction - math.pi / 2 - math.radians(
                            self.type.attack_3.spread * (a + 1)) + math.radians(
                            random.randrange(-self.type.attack_3.random_spread, self.type.attack_3.random_spread + 1)), self.type.level)
                        bullet_group.add(b)
                        b = Bullet(self, self.type.attack_3.bullet, direction - math.pi / 2 + math.radians(
                            self.type.attack_3.spread * (a + 1)) + math.radians(
                            random.randrange(-self.type.attack_3.random_spread, self.type.attack_3.random_spread + 1)), self.type.level)
                        bullet_group.add(b)
                        b = Bullet(self, self.type.attack_3.bullet, direction + math.pi / 2 - math.radians(
                            self.type.attack_3.spread * (a + 1)) + math.radians(
                            random.randrange(-self.type.attack_3.random_spread, self.type.attack_3.random_spread + 1)), self.type.level)
                        bullet_group.add(b)
                        b = Bullet(self, self.type.attack_3.bullet, direction + math.pi / 2 + math.radians(
                            self.type.attack_3.spread * (a + 1)) + math.radians(
                            random.randrange(-self.type.attack_3.random_spread, self.type.attack_3.random_spread + 1)), self.type.level)
                        bullet_group.add(b)
            elif "spawn" in self.type.attack_3.type:
                if len(ally_group.sprites()) < int(self.type.attack_3.type[5:-1]):
                    d = 9999
                    for e in enemy_group:
                        new_d = math.hypot(self.rect.centerx - e.rect.centerx, self.rect.centery - e.rect.centery)
                        if new_d < d:
                            d = new_d
                            target = e
                    if d == 9999:
                        target = None
                    a = Ally(self.type.attack_3.bullet, self.rect.center, target, camera, self.type.level)
                    ally_group.add(a)
                    self.fireclock_3 = 60 // self.type.attack_3.firerate
                    self.ammo_3 -= 1

            elif "laser" not in self.type.attack_3.type:
                b = Bullet(self, self.type.attack_3.bullet, direction + math.radians(
                    random.randrange(-self.type.attack_3.random_spread, self.type.attack_3.random_spread + 1)), self.type.level)
                bullet_group.add(b)
            if self.type.attack_3.type == "spiral":
                direction += math.radians(self.type.attack_3.spread)

        if "laser" in self.type.attack_3.type:
            if self.fireclock_3 >= self.type.attack_3.firerate:
                pygame.draw.line(screen, BLUE, (
                self.rect.centerx + WIN_W / 2 - camera.rect.centerx, self.rect.centery + WIN_H / 2 - camera.rect.centery), (
                                 self.rect.centerx + math.cos(direction) * 1000 + WIN_W / 2 - camera.rect.centerx,
                                 self.rect.centery - math.sin(direction) * 1000 + WIN_H / 2 - camera.rect.centery),
                                 self.type.attack_3.spread)
                for target in enemy_group:
                    target_dist = math.hypot(self.rect.centerx - target.rect.centerx,
                                             self.rect.centery - target.rect.centery)
                    if target.rect.collidepoint((self.rect.centerx + math.cos(direction) * target_dist,
                                                 self.rect.centery - math.sin(direction) * target_dist)):
                        target.hp -= float(self.type.attack_3.type[5:-1])
                self.ammo_3 -= 2
            else:
                pygame.draw.line(screen, LIGHT_BLUE, (
                self.rect.centerx + WIN_W / 2 - camera.rect.centerx, self.rect.centery + WIN_H / 2 - camera.rect.centery), (
                                 self.rect.centerx + math.cos(direction) * 1000 + WIN_W / 2 - camera.rect.centerx,
                                 self.rect.centery - math.sin(direction) * 1000 + WIN_H / 2 - camera.rect.centery),
                                 int(self.type.attack_3.spread/2 * (self.fireclock_3) / self.type.attack_3.firerate))
                self.ammo_3 -= 1
            self.fireclock_3 += 1
        elif "spawn" not in self.type.attack_3.type:
            self.fireclock_3 = 60 // self.type.attack_3.firerate
            self.ammo_3 -= 1


class Ally(pygame.sprite.Sprite):
    def __init__(self, ally_type, startpos, target, camera, scaling):
        pygame.sprite.Sprite.__init__(self)
        self.type = ally_type
        self.scaling = scaling
        if self.type.image:
            self.image = pygame.transform.scale(self.type.image, (self.type.width, self.type.height))
        else:
            self.image = pygame.transform.scale(pygame.transform.rotate(pygame.image.load("image/huey.png"), 90), (self.type.width, self.type.height))
        self.rect = self.image.get_rect()
        self.rect.x = startpos[0]
        self.rect.y = startpos[1]
        self.fireclock = 0
        self.volley = 0
        self.direction = 0
        self.hp = self.type.health*(2**(scaling-1))
        self.target = target
        if "strafe" in self.type.behavior:
            self.targety = float(self.type.behavior[6:self.type.behavior.find(";")]) + camera.rect.top
            self.strafe_radius = float(self.type.behavior[self.type.behavior.find(";") + 1: -1])
            self.targetx = self.rect.x + camera.rect.x
        elif "snipe" in self.type.behavior:
            self.basey = float(self.type.behavior[5:self.type.behavior.find(";")])
            self.targety = self.basey + camera.rect.top
            self.strafe_radius = float(self.type.behavior[self.type.behavior.find(";") + 1: -1])
            self.targetx = self.rect.x + camera.rect.x

        elif "dive" in self.type.behavior:
            self.targety = camera.rect.top - self.type.speed*150
            if "player" in self.type.behavior:
                if random.randrange(2) == 1:
                    self.targetx = self.target.rect.x + random.randrange(int(self.type.behavior[10:-1])//2, int(self.type.behavior[10:-1]) + 1)
                else:
                    self.targetx = self.target.rect.x - random.randrange(int(self.type.behavior[10:-1])//2, int(self.type.behavior[10:-1]) + 1)
            else:
                self.targetx = self.rect.x + random.randrange(-int(self.type.behavior[4:-1]), int(self.type.behavior[4:-1]) + 1)
            self.strafe_radius = 100
        elif "bomb" in self.type.behavior:
            self.basey = float(self.type.behavior[4:self.type.behavior.find(";")])
            self.targety = self.basey + camera.rect.top
            self.targetx = self.rect.x
            self.strafe_radius = float(self.type.behavior[self.type.behavior.find(";") + 1: -1])
        elif "follow" in self.type.behavior:
            self.targetx = self.rect.x
            self.targety = self.rect.y
            self.strafe_radius = float(self.type.behavior[self.type.behavior.find(";") + 1: -1])
        else:
            self.strafe_radius = 100
        self.x = self.rect.x
        self.y = self.rect.y
        self.xvel = 0
        self.yvel = 0


    def update(self, screen, camera, player):
        if not self.target or self.target.hp <= 0:
            d = 9999
            for e in enemy_group:
                new_d = math.hypot(self.rect.centerx - e.rect.centerx, self.rect.centery - e.rect.centery)
                if new_d < d:
                    d = new_d
                    self.target = e
        if self.target:
            if self.hp <= 0:
                self.kill()
                self.indicator.kill()
            if "laser" in self.type.attack.type:
                if self.volley <= self.type.attack.volley / 2:
                    pygame.draw.line(screen, RED, (self.rect.centerx + WIN_W / 2 - camera.rect.centerx, self.rect.centery + WIN_H / 2 - camera.rect.centery), (self.rect.centerx + math.cos(self.direction) * 1000 + WIN_W / 2 - camera.rect.centerx, self.rect.centery - math.sin(self.direction) * 1000 + WIN_H / 2 - camera.rect.centery), self.type.attack.spread)
                    player_dist = math.hypot(self.rect.centerx - self.target.rect.centerx, self.rect.centery - self.target.rect.centery)
                    if self.target.rect.collidepoint((self.rect.centerx + math.cos(self.direction) * player_dist, self.rect.centery - math.sin(self.direction) * player_dist)) and self.fireclock == 0:
                        damage = float(self.type.attack.type[5:-1])
                        self.target.hp -= damage
                        self.fireclock = 60 // self.type.attack.firerate
                else:
                    pygame.draw.line(screen, ORANGE, (self.rect.centerx + WIN_W / 2 - camera.rect.centerx, self.rect.centery + WIN_H / 2 - camera.rect.centery), (self.rect.centerx + math.cos(self.direction) * 1000 + WIN_W / 2 - camera.rect.centerx, self.rect.centery - math.sin(self.direction) * 1000 + WIN_H / 2 - camera.rect.centery), int(self.type.attack.spread * (self.type.attack.volley - self.volley) / self.type.attack.volley))

            if self.fireclock == 0:
                if self.volley == 0:
                    self.volley = self.type.attack.volley
                    self.fireclock = self.type.attack.cooldown
                else:
                    if self.type.attack.aim_shot == True and type(
                            self.type.attack.aim_shot) != int or self.volley == self.type.attack.volley:
                        self.direction = math.atan2(self.rect.centery - self.target.rect.centery,
                                                    self.target.rect.centerx - self.rect.centerx)
                    if self.volley == self.type.attack.volley:
                        self.fireclock = 60 // self.type.attack.firerate
                    if self.type.attack.aim_shot >= 1:
                        player_direction = math.atan2(self.rect.centery - self.target.rect.centery,
                                                      self.target.rect.centerx - self.rect.centerx)
                        if self.direction + math.radians(
                                self.type.attack.aim_shot) / 60 > player_direction and self.direction - math.radians(
                            self.type.attack.aim_shot) / 60 < player_direction:
                            self.direction = player_direction
                        else:
                            if self.direction >= 0:
                                if player_direction > self.direction or player_direction < self.direction - math.pi:
                                    self.direction += math.radians(self.type.attack.aim_shot) / 60
                                else:
                                    self.direction -= math.radians(self.type.attack.aim_shot) / 60
                            else:
                                if player_direction > self.direction and player_direction < self.direction + math.pi:
                                    self.direction += math.radians(self.type.attack.aim_shot) / 60
                                else:
                                    self.direction -= math.radians(self.type.attack.aim_shot) / 60
                    self.volley -= 1
                    if "laser" not in self.type.attack.type:
                        for a in range(self.type.attack.shots):
                            self.fireclock = 60 // self.type.attack.firerate
                            if "shotgun" in self.type.attack.type:
                                for a in range(int(self.type.attack.type[7:-1])):
                                    b = Bullet(self, self.type.attack.bullet, self.direction + math.radians(
                                        -self.type.attack.spread / 2 + self.type.attack.spread * a / (
                                                int(self.type.attack.type[7:-1]) - 1)) + math.radians(
                                        random.randrange(-self.type.attack.random_spread,
                                                         self.type.attack.random_spread + 1)), self.scaling)
                                    bullet_group.add(b)
                            elif "sides" in self.type.attack.type:
                                if int(self.type.attack.type[5:-1]) % 2 == 0:
                                    for a in range(int(self.type.attack.type[5:-1]) // 2):
                                        b = Bullet(self, self.type.attack.bullet,
                                                   self.direction - math.pi / 2 - math.radians(
                                                       self.type.attack.spread * (a + 1)) + math.radians(
                                                       random.randrange(-self.type.attack.random_spread,
                                                                        self.type.attack.random_spread + 1)),
                                                   self.scaling)
                                        bullet_group.add(b)
                                        b = Bullet(self, self.type.attack.bullet,
                                                   self.direction - math.pi / 2 + math.radians(
                                                       self.type.attack.spread * (a + 1)) + math.radians(
                                                       random.randrange(-self.type.attack.random_spread,
                                                                        self.type.attack.random_spread + 1)),
                                                   self.scaling)
                                        bullet_group.add(b)
                                        b = Bullet(self, self.type.attack.bullet,
                                                   self.direction + math.pi / 2 - math.radians(
                                                       self.type.attack.spread * (a + 1)) + math.radians(
                                                       random.randrange(-self.type.attack.random_spread,
                                                                        self.type.attack.random_spread + 1)),
                                                   self.scaling)
                                        bullet_group.add(b)
                                        b = Bullet(self, self.type.attack.bullet,
                                                   self.direction + math.pi / 2 + math.radians(
                                                       self.type.attack.spread * (a + 1)) + math.radians(
                                                       random.randrange(-self.type.attack.random_spread,
                                                                        self.type.attack.random_spread + 1)),
                                                   self.scaling)
                                        bullet_group.add(b)
                                else:
                                    b = Bullet(self, self.type.attack.bullet,
                                               self.direction - math.pi / 2 + math.radians(
                                                   random.randrange(-self.type.attack.random_spread,
                                                                    self.type.attack.random_spread + 1)),
                                               self.scaling)
                                    bullet_group.add(b)
                                    b = Bullet(self, self.type.attack.bullet,
                                               self.direction + math.pi / 2 + math.radians(
                                                   random.randrange(-self.type.attack.random_spread,
                                                                    self.type.attack.random_spread + 1)),
                                               self.scaling)
                                    bullet_group.add(b)
                                    for a in range(int(self.type.attack.type[5:-1]) // 2 - 1):
                                        b = Bullet(self, self.type.attack.bullet,
                                                   self.direction - math.pi / 2 - math.radians(
                                                       self.type.attack.spread * (a + 1)) + math.radians(
                                                       random.randrange(-self.type.attack.random_spread,
                                                                        self.type.attack.random_spread + 1)),
                                                   self.scaling)
                                        bullet_group.add(b)
                                        b = Bullet(self, self.type.attack.bullet,
                                                   self.direction - math.pi / 2 + math.radians(
                                                       self.type.attack.spread * (a + 1)) + math.radians(
                                                       random.randrange(-self.type.attack.random_spread,
                                                                        self.type.attack.random_spread + 1)),
                                                   self.scaling)
                                        bullet_group.add(b)
                                        b = Bullet(self, self.type.attack.bullet,
                                                   self.direction + math.pi / 2 - math.radians(
                                                       self.type.attack.spread * (a + 1)) + math.radians(
                                                       random.randrange(-self.type.attack.random_spread,
                                                                        self.type.attack.random_spread + 1)),
                                                   self.scaling)
                                        bullet_group.add(b)
                                        b = Bullet(self, self.type.attack.bullet,
                                                   self.direction + math.pi / 2 + math.radians(
                                                       self.type.attack.spread * (a + 1)) + math.radians(
                                                       random.randrange(-self.type.attack.random_spread,
                                                                        self.type.attack.random_spread + 1)),
                                                   self.scaling)
                                        bullet_group.add(b)

                            else:
                                b = Bullet(self, self.type.attack.bullet, self.direction + math.radians(
                                    random.randrange(-self.type.attack.random_spread,
                                                     self.type.attack.random_spread + 1)),
                                           self.scaling)
                                bullet_group.add(b)
                            if self.type.attack.type == "spiral":
                                self.direction += math.radians(self.type.attack.spread)

            else:
                if self.fireclock <= 1:
                    self.fireclock = 0
                else:
                    self.fireclock -= 1

        if math.hypot(self.targetx - self.rect.x, self.targety - self.rect.y) > self.type.speed * 20:

            if "dive" in self.type.behavior and (self.rect.right < 0 or self.rect.left > WIN_W * 3/2 or self.rect.top > camera.rect.bottom or self.rect.bottom < camera.rect.top):
                self.kill()

            if math.fabs(self.rect.x - self.targetx) > self.type.speed*100:
                self.xvel += self.type.speed * (self.targetx - self.rect.x)/math.hypot(self.targetx - self.rect.x, self.targety - self.rect.y)

            elif math.fabs(self.xvel) > math.fabs(self.type.speed*10):
                if self.xvel < 0:
                    self.xvel += self.type.speed
                else:
                    self.xvel -= self.type.speed

            else:
                self.xvel += self.type.speed * ((self.targetx - self.rect.x)/math.hypot(self.targetx - self.rect.x, self.targety - self.rect.y)) / 3

            if math.fabs(self.rect.y - self.targety) > self.type.speed*100:
                self.yvel -= self.type.speed * (self.targety - self.rect.y)/math.hypot(self.targetx - self.rect.x, self.targety - self.rect.y)

            elif math.fabs(self.yvel) > math.fabs(self.type.speed*10):
                if self.yvel < 0:
                    self.yvel += self.type.speed
                else:
                    self.yvel -= self.type.speed

            else:
                self.yvel -= self.type.speed * ((self.targety - self.rect.y)/math.hypot(self.targetx - self.rect.x, self.targety - self.rect.y)) / 3
        else:
            if self.rect.colliderect(camera.rect):
                if "strafe" in self.type.behavior:
                    while math.hypot(self.targetx - self.rect.x, self.targety - self.rect.y) > self.strafe_radius or math.hypot(self.targetx - self.rect.x, self.targety - self.rect.y) < self.strafe_radius/2 or self.targetx < camera.rect.left + self.type.speed*100 or self.targetx > camera.rect.right - self.type.speed*100 or self.targety < camera.rect.top + self.type.speed*100 or self.targety > camera.rect.bottom - self.type.speed*100:
                        self.targetx = random.randrange(self.rect.x - self.strafe_radius, self.rect.x + self.strafe_radius + 1)
                        self.targety = random.randrange(self.rect.y - self.strafe_radius, self.rect.y + self.strafe_radius + 1)
                elif "snipe" in self.type.behavior:
                    if math.fabs(self.rect.y - (self.basey + camera.rect.top)) < self.strafe_radius * 1.5:
                        while math.hypot(self.targetx - self.rect.x, self.targety - self.rect.y) > self.strafe_radius or math.hypot(self.targetx - self.rect.x, self.targety - self.rect.y) < self.strafe_radius / 2 or self.targetx < camera.rect.left + self.type.speed * 100 or self.targetx > camera.rect.right - self.type.speed * 100 or self.targety < camera.rect.top + self.type.speed * 100 or self.targety > camera.rect.bottom - self.type.speed * 100 or self.targety < self.basey - self.strafe_radius + camera.rect.top or self.targety > self.basey + self.strafe_radius + camera.rect.top:
                            self.targetx = random.randrange(self.rect.x - self.strafe_radius, self.rect.x + self.strafe_radius + 1)
                            self.targety = random.randrange(self.rect.y - self.strafe_radius, self.rect.y + self.strafe_radius + 1)
                    else:
                        i = 1
                        while math.hypot(self.targetx - self.rect.x, self.targety - self.rect.y) > self.strafe_radius * i/2 or math.hypot(self.targetx - self.rect.x, self.targety - self.rect.y) < self.strafe_radius/2 * i/2:
                            self.targetx = random.randrange(camera.rect.left + self.type.speed*100, camera.rect.right - self.type.speed*100 + 1)
                            self.targety = random.randrange((self.basey + camera.rect.top) - self.strafe_radius, (self.basey + camera.rect.top) + self.strafe_radius + 1)
                            if self.strafe_radius * i/2 < math.fabs(self.rect.y - (self.basey + camera.rect.top)) * 1.5:
                                i += 1
                elif "bomb" in self.type.behavior:
                    if self.fireclock < 120 and self.target != None:
                        while math.hypot(self.targetx - self.target.rect.x, self.targety - (self.target.rect.y - self.strafe_radius/2)) > self.strafe_radius * 2 or math.hypot(self.targetx - self.target.rect.x, self.targety - (self.target.rect.y - self.strafe_radius/2)) < self.strafe_radius:
                            self.targetx = random.randrange(self.target.rect.x - self.strafe_radius*2, self.target.rect.x + self.strafe_radius*2 + 1)
                            self.targety = random.randrange(self.target.rect.y - self.strafe_radius*2, self.target.rect.y + self.strafe_radius*2 + 1)
                    elif math.fabs(self.rect.y - (self.basey + camera.rect.top)) < self.strafe_radius * 1.5:
                        i = 1
                        while math.hypot(self.targetx - self.rect.x, self.targety - self.rect.y) > self.strafe_radius * i/2 or math.hypot(self.targetx - self.rect.x, self.targety - self.rect.y) < self.strafe_radius/2 * i/2:
                            self.targetx = random.randrange(camera.rect.left + self.type.speed*100, camera.rect.right - self.type.speed*100 + 1)
                            self.targety = random.randrange((self.basey + camera.rect.top) - self.strafe_radius, (self.basey + camera.rect.top) + self.strafe_radius + 1)
                            if self.strafe_radius * i/2 < math.fabs(self.rect.y - (self.basey + camera.rect.top)) * 1.5:
                                i += 1
                    else:
                        while math.hypot(self.targetx - self.rect.x, self.targety - self.rect.y) > self.strafe_radius or math.hypot(self.targetx - self.rect.x, self.targety - self.rect.y) < self.strafe_radius / 2 or self.targetx < camera.rect.left + self.type.speed * 100 or self.targetx > camera.rect.right - self.type.speed * 100 or self.targety < camera.rect.top + self.type.speed * 100 or self.targety > camera.rect.bottom - self.type.speed * 100:
                            self.targetx = random.randrange(self.rect.x - self.strafe_radius, self.rect.x + self.strafe_radius + 1)
                            self.targety = random.randrange(self.rect.y - self.strafe_radius, self.rect.y + self.strafe_radius + 1)
                elif "follow" in self.type.behavior:
                    if self.strafe_radius == 0:
                        self.x = player.rect.x - (self.rect.width - player.rect.width) / 2
                        self.y = player.rect.y - (self.rect.height - player.rect.height) / 2
                        self.targetx = player.rect.x - (self.rect.width - player.rect.width) / 2
                        self.targety = player.rect.y - (self.rect.height - player.rect.height) / 2
                        self.xvel = 0
                        self.yvel = 0
                    else:
                        while math.hypot(self.targetx - player.rect.x, self.targety - (player.rect.y - self.strafe_radius / 2)) > self.strafe_radius * 2 or math.hypot(self.targetx - player.rect.x, self.targety - (player.rect.y - self.strafe_radius / 2)) < self.strafe_radius or self.targetx < camera.rect.left + self.type.speed * 100 or self.targetx > camera.rect.right - self.type.speed * 100 or self.targety < camera.rect.top + self.type.speed * 100 or self.targety > camera.rect.bottom - self.type.speed * 100:
                            self.targetx = random.randrange(player.rect.x - self.strafe_radius, player.rect.x + self.strafe_radius + 1)
                            self.targety = random.randrange(player.rect.y - self.strafe_radius, player.rect.y + self.strafe_radius)
            else:
                i = 1
                while not camera.rect.collidepoint(self.targetx, self.targety):
                    self.targetx = random.randrange(self.rect.x - self.strafe_radius * i/2, self.rect.x + self.strafe_radius * i/2 + 1)
                    self.targety = random.randrange(self.rect.y - self.strafe_radius * i/2, self.rect.y + self.strafe_radius * i/2 + 1)
                    if self.strafe_radius * i/2 < WIN_H:
                        i += 1

        if math.fabs(math.hypot(self.xvel, self.yvel)) > self.type.speed * 20:
            self.xvel *= self.type.speed*20/math.fabs(math.hypot(self.xvel, self.yvel))
            self.yvel *= self.type.speed*20/math.fabs(math.hypot(self.xvel, self.yvel))
        self.x += self.xvel
        self.y -= self.yvel
        self.rect.x = self.x
        self.rect.y = self.y
        if math.fabs(self.xvel) < 0.01:
            self.xvel = 0
        else:
            self.xvel *= 0.98
        if math.fabs(self.yvel) < 0.01:
            self.yvel = 0
        else:
            self.yvel *= 0.98


class Bullet(pygame.sprite.Sprite):
    def __init__(self, player, bullet_type, direction, scaling):
        pygame.sprite.Sprite.__init__(self)
        self.type = bullet_type
        self.image = pygame.Surface((self.type.width, self.type.height))
        if self.type.image:
            self.image = pygame.transform.scale(self.type.image, (bullet_type.width, bullet_type.height))
        else:
            self.image.fill(BLUE)
        self.rect = self.image.get_rect()
        self.spawner = player
        self.rect.centerx = self.spawner.rect.centerx
        self.rect.centery = self.spawner.rect.centery
        self.direction = direction
        self.player_direction = self.spawner.direction
        self.scaling = scaling

        if type(self.type.speed) != str:
            self.speed = self.type.speed
        else:
            self.speed = float(self.type.speed[0:self.type.speed.find(";")])
        if self.type.accel == False:
            self.xvel = math.cos(direction) * self.speed
            self.yvel = math.sin(direction) * self.speed
        else:
            if type(self.type.accel) == int:
                self.xvel = math.cos(direction) * self.type.accel
                self.yvel = math.sin(direction) * self.type.accel
            else:
                speed = int(self.type.accel[0:self.type.accel.find(";")]) + random.randrange(
                    -int(self.type.accel[self.type.accel.find(";") + 1:-1]),
                    int(self.type.accel[self.type.accel.find(";") + 1:-1]) + 1)
                self.xvel = math.cos(direction) * speed
                self.yvel = math.sin(direction) * speed
        self.x = self.rect.x
        self.y = self.rect.y
        if type(self.type.delay) == int:
            self.fuse = self.type.delay
        else:
            self.fuse = int(self.type.delay[0:self.type.delay.find(";")]) + random.randrange(-int(self.type.delay[self.type.delay.find(";") + 1:-1]), int(self.type.delay[self.type.delay.find(";") + 1:-1]) + 1)
        self.target = None

    def update(self, camera):
        if self.type.homing_speed and (not self.target or self.target.hp <= 0):
            d = 9999
            for e in enemy_group:
                new_d = math.hypot(self.rect.centerx - e.rect.centerx, self.rect.centery - e.rect.centery)
                if new_d < d:
                    d = new_d
                    self.target = e

        if self.fuse == 0:
            if self.direction < -math.pi:
                self.direction += 2 * math.pi
            if self.direction > math.pi:
                self.direction -= 2 * math.pi
            if self.type.homing_speed > 0 and type(self.type.homing_speed) == int and self.target and self.target.hp >= 0:
                target_direction = math.atan2(self.rect.centery - self.target.rect.centery, self.target.rect.centerx - self.rect.centerx)
                if self.direction >= 0:
                    if target_direction > self.direction or target_direction < self.direction - math.pi:
                        self.direction += math.radians(self.type.homing_speed) / 60
                    else:
                        self.direction -= math.radians(self.type.homing_speed) / 60
                else:
                    if target_direction > self.direction and target_direction < self.direction + math.pi:
                        self.direction += math.radians(self.type.homing_speed) / 60
                    else:
                        self.direction -= math.radians(self.type.homing_speed) / 60

            if self.type.accel:
                self.xvel += math.cos(self.direction) * self.speed
                self.yvel += math.sin(self.direction) * self.speed
            else:
                self.xvel = math.cos(self.direction) * self.speed
                self.yvel = math.sin(self.direction) * self.speed

        else:
            if self.type.homing_speed:
                if not self.target or self.target.hp <= 0:
                    self.x += self.xvel
                    self.y -= self.yvel
                    self.rect.x = self.x
                    self.rect.y = self.y
                else:
                    target_direction = math.atan2(self.rect.centery - self.target.rect.centery, self.target.rect.centerx - self.rect.centerx)
                    if self.type.accel != False:
                        if self.direction >= 0:
                            if target_direction > self.direction or target_direction < self.direction - math.pi:
                                self.direction += math.radians(self.type.homing_speed) / 60
                            else:
                                self.direction -= math.radians(self.type.homing_speed) / 60
                        else:
                            if target_direction > self.direction and target_direction < self.direction + math.pi:
                                self.direction += math.radians(self.type.homing_speed) / 60
                            else:
                                self.direction -= math.radians(self.type.homing_speed) / 60
                self.fuse -= 1
                if self.fuse == 0:
                    if self.type.accel != False:
                        if type(self.type.homing_speed) == bool:
                            if not self.type.homing_speed:
                                self.direction = self.player_direction + math.radians(random.randrange(-self.type.spread, self.type.spread + 1))
                            else:
                                self.direction = math.atan2(self.rect.centery + WIN_H / 2 - camera.rect.centery - pygame.mouse.get_pos()[1], pygame.mouse.get_pos()[0] - (self.rect.centerx + WIN_W / 2 - camera.rect.centerx))
                        else:
                            if self.type.homing_speed:
                                d = 9999
                                for e in enemy_group:
                                    new_d = math.hypot(pygame.mouse.get_pos()[0] - (e.rect.centerx + WIN_W / 2 - camera.rect.centerx), e.rect.centery + WIN_H / 2 - camera.rect.centery - pygame.mouse.get_pos()[1])
                                    if new_d < d:
                                        d = new_d
                                        self.target = e

            if math.fabs(self.xvel) < 0.01:
                self.xvel = 0
            else:
                self.xvel *= 0.95
            if math.fabs(self.yvel) < 0.01:
                self.yvel = 0
            else:
                self.yvel *= 0.95

        if type(self.type.speed) != str:
            self.xvel *= 0.995
        else:
            self.xvel *= float(self.type.speed[self.type.speed.find(";") + 1: -1])

        if type(self.type.speed) != str:
            self.yvel *= 0.995
        else:
            self.yvel *= float(self.type.speed[self.type.speed.find(";") + 1: -1])
        self.x += self.xvel
        self.y -= self.yvel
        self.rect.x = self.x
        self.rect.y = self.y
        enemies_list = pygame.sprite.spritecollide(self, enemy_group, False)
        for e in enemies_list:
            e.hp -= self.type.damage*(2**(self.scaling-1))
            self.kill()
        if self.rect.x < 0 or self.rect.x > WIN_W * 3 / 2 or self.rect.y < 0 or self.rect.y > WIN_H * 3 / 2:
            self.kill()

class Enemy(pygame.sprite.Sprite):
    def __init__(self, enemy_type, startpos, camera, game, scaling=0):
        pygame.sprite.Sprite.__init__(self)
        self.type = enemy_type
        self.scaling = scaling
        if self.type.image:
            self.image = pygame.transform.scale(self.type.image, (self.type.width, self.type.height))
        else:
            self.image = pygame.transform.scale(pygame.transform.rotate(pygame.image.load("image/huey.png"), 90), (self.type.width, self.type.height))
        self.rect = self.image.get_rect()
        self.rect.x = startpos[0]
        self.rect.y = startpos[1]
        self.fireclock = 0
        self.volley = 0
        self.direction = 0
        self.hp = self.type.health*2**self.scaling
        self.target = None
        if "strafe" in self.type.behavior:
            self.targety = float(self.type.behavior[6:self.type.behavior.find(";")]) + camera.rect.top
            self.strafe_radius = float(self.type.behavior[self.type.behavior.find(";") + 1: -1])
            self.targetx = self.rect.x
        elif "snipe" in self.type.behavior:
            self.basey = float(self.type.behavior[5:self.type.behavior.find(";")])
            self.targety = self.basey + camera.rect.top
            self.strafe_radius = float(self.type.behavior[self.type.behavior.find(";") + 1: -1])
            self.targetx = self.rect.x

        elif "dive" in self.type.behavior:
            self.targety = WIN_H * 3/2 + self.type.speed*100
            if "player" in self.type.behavior:
                target = game.player
                if random.randrange(2) == 1:
                    self.targetx = target.rect.x + random.randrange(int(self.type.behavior[10:-1])//2, int(self.type.behavior[10:-1]) + 1)
                else:
                    self.targetx = target.rect.x - random.randrange(int(self.type.behavior[10:-1])//2, int(self.type.behavior[10:-1]) + 1)
            else:
                self.targetx = self.rect.x + random.randrange(-int(self.type.behavior[4:-1]), int(self.type.behavior[4:-1]) + 1)
            self.strafe_radius = 100
        elif "bomb" in self.type.behavior:
            self.basey = float(self.type.behavior[4:self.type.behavior.find(";")])
            self.targety = self.basey + camera.rect.top
            self.targetx = self.rect.x
            self.strafe_radius = float(self.type.behavior[self.type.behavior.find(";") + 1: -1])
        else:
            self.strafe_radius = 100
        self.x = self.rect.x
        self.y = self.rect.y
        self.xvel = 0
        self.yvel = 0
        e = Enemy_Indicator(self)
        self.indicator = e
        enemy_indicator_group.add(e)
        self.health_bar = Bar(self.rect.centerx - (self.rect.width+self.rect.height)/4, self.rect.y - 10, RED, 1, None, length=(self.rect.width+self.rect.height)/2, height=5)
        bar_group.add(self.health_bar)

    def update(self, screen, camera):
        if not self.target or self.target.hp <= 0:
            d = 9999
            for a in ally_group:
                new_d = math.hypot(self.rect.centerx - a.rect.centerx, self.rect.centery - a.rect.centery)
                if new_d < d:
                    d = new_d
                    self.target = a
            for s in ship_group:
                new_d = math.hypot(self.rect.centerx - s.rect.centerx, self.rect.centery - s.rect.centery)
                if new_d < d:
                    d = new_d
                    self.target = s


        if self.hp <= 0:
            self.indicator.kill()
            self.health_bar.kill()
            game.points += round(10*1.5**self.scaling)
            self.kill()
        if "laser" in self.type.attack.type:
            if self.volley <= self.type.attack.volley / 2:
                pygame.draw.line(screen, RED, (
                self.rect.centerx + WIN_W / 2 - camera.rect.centerx, self.rect.centery + WIN_H / 2 - camera.rect.centery), (self.rect.centerx + math.cos(self.direction) * 1000 + WIN_W / 2 - camera.rect.centerx, self.rect.centery - math.sin(self.direction) * 1000 + WIN_H / 2 - camera.rect.centery), self.type.attack.spread)
                for s in ship_group:
                    player_dist = math.hypot(self.rect.centerx - s.rect.centerx, self.rect.centery - s.rect.centery)
                    if s.rect.collidepoint((self.rect.centerx + math.cos(self.direction) * player_dist, self.rect.centery - math.sin(self.direction) * player_dist)) and self.fireclock == 0:
                        damage = float(self.type.attack.type[5:-1])
                        if s.type.max_shield and s.shield_active:
                            s.shield -= damage
                            if damage > s.type.shield_def_abs:
                                s.hp -= (damage - s.type.shield_def_abs) * (1 - s.type.shield_def_mult)
                                s.hp_regen_timer = 30
                            s.shield_regen_timer = 30
                        else:
                            s.hp -= damage
                            s.hp_regen_timer = 30
                        self.fireclock = 60 // self.type.attack.firerate
                for a in ally_group:
                    player_dist = math.hypot(self.rect.centerx - a.rect.centerx, self.rect.centery - a.rect.centery)
                    if a.rect.collidepoint((self.rect.centerx + math.cos(self.direction) * player_dist, self.rect.centery - math.sin(self.direction) * player_dist)) and self.fireclock == 0:
                        damage = float(self.type.attack.type[5:-1])
                        a.hp -= damage
                        if a.hp <= 0:
                            a.kill()
            else:
                pygame.draw.line(screen, ORANGE, (
                self.rect.centerx + WIN_W / 2 - camera.rect.centerx, self.rect.centery + WIN_H / 2 - camera.rect.centery), (self.rect.centerx + math.cos(self.direction) * 1000 + WIN_W / 2 - camera.rect.centerx, self.rect.centery - math.sin(self.direction) * 1000 + WIN_H / 2 - camera.rect.centery), int(self.type.attack.spread * (self.type.attack.volley - self.volley) / self.type.attack.volley))

        if self.fireclock == 0:
            if self.volley == 0:
                self.volley = self.type.attack.volley
                self.fireclock = self.type.attack.cooldown
            else:
                if self.type.attack.aim_shot == True and type(self.type.attack.aim_shot) != int or self.volley == self.type.attack.volley:
                    self.direction = math.atan2(self.rect.centery - self.target.rect.centery, self.target.rect.centerx - self.rect.centerx)
                if self.volley == self.type.attack.volley:
                    self.fireclock = 60 // self.type.attack.firerate
                if self.type.attack.aim_shot >= 1:
                    player_direction = math.atan2(self.rect.centery - self.target.rect.centery, self.target.rect.centerx - self.rect.centerx)
                    if self.direction + math.radians(self.type.attack.aim_shot)/60 > player_direction and self.direction - math.radians(self.type.attack.aim_shot)/60 < player_direction:
                        self.direction = player_direction
                    else:
                        if self.direction >= 0:
                            if player_direction > self.direction or player_direction < self.direction - math.pi:
                                self.direction += math.radians(self.type.attack.aim_shot)/60
                            else:
                                self.direction -= math.radians(self.type.attack.aim_shot)/60
                        else:
                            if player_direction > self.direction and player_direction < self.direction + math.pi:
                                self.direction += math.radians(self.type.attack.aim_shot)/60
                            else:
                                self.direction -= math.radians(self.type.attack.aim_shot)/60
                self.volley -= 1
                if "laser" not in self.type.attack.type:
                    for a in range(self.type.attack.shots):
                        self.fireclock = 60 // self.type.attack.firerate
                        if "shotgun" in self.type.attack.type:
                            for a in range(int(self.type.attack.type[7:-1])):
                                e = Enemy_Bullet(self, self.type.attack.bullet, self.direction + math.radians(-self.type.attack.spread/2 + self.type.attack.spread * a/(int(self.type.attack.type[7:-1])-1)) + math.radians(random.randrange(-self.type.attack.random_spread, self.type.attack.random_spread + 1)), self.scaling)
                                enemy_bullet_group.add(e)
                        elif "sides" in self.type.attack.type:
                            if int(self.type.attack.type[5:-1]) % 2 == 0:
                                for a in range(int(self.type.attack.type[5:-1])//2):
                                    e = Enemy_Bullet(self, self.type.attack.bullet, self.direction - math.pi/2 - math.radians(self.type.attack.spread*(a + 1)) + math.radians(random.randrange(-self.type.attack.random_spread, self.type.attack.random_spread + 1)), self.scaling)
                                    enemy_bullet_group.add(e)
                                    e = Enemy_Bullet(self, self.type.attack.bullet, self.direction - math.pi/2 + math.radians(self.type.attack.spread*(a + 1)) + math.radians(random.randrange(-self.type.attack.random_spread, self.type.attack.random_spread + 1)), self.scaling)
                                    enemy_bullet_group.add(e)
                                    e = Enemy_Bullet(self, self.type.attack.bullet, self.direction + math.pi/2 - math.radians(self.type.attack.spread*(a + 1)) + math.radians(random.randrange(-self.type.attack.random_spread, self.type.attack.random_spread + 1)), self.scaling)
                                    enemy_bullet_group.add(e)
                                    e = Enemy_Bullet(self, self.type.attack.bullet, self.direction + math.pi/2 + math.radians(self.type.attack.spread*(a + 1)) + math.radians(random.randrange(-self.type.attack.random_spread, self.type.attack.random_spread + 1)), self.scaling)
                                    enemy_bullet_group.add(e)
                            else:
                                e = Enemy_Bullet(self, self.type.attack.bullet, self.direction - math.pi/2 + math.radians(random.randrange(-self.type.attack.random_spread, self.type.attack.random_spread + 1)), self.scaling)
                                enemy_bullet_group.add(e)
                                e = Enemy_Bullet(self, self.type.attack.bullet, self.direction + math.pi/2 + math.radians(random.randrange(-self.type.attack.random_spread, self.type.attack.random_spread + 1)), self.scaling)
                                enemy_bullet_group.add(e)
                                for a in range(int(self.type.attack.type[5:-1])//2 - 1):
                                    e = Enemy_Bullet(self, self.type.attack.bullet, self.direction - math.pi/2 - math.radians(self.type.attack.spread*(a + 1)) + math.radians(random.randrange(-self.type.attack.random_spread, self.type.attack.random_spread + 1)), self.scaling)
                                    enemy_bullet_group.add(e)
                                    e = Enemy_Bullet(self, self.type.attack.bullet, self.direction - math.pi/2 + math.radians(self.type.attack.spread*(a + 1)) + math.radians(random.randrange(-self.type.attack.random_spread, self.type.attack.random_spread + 1)), self.scaling)
                                    enemy_bullet_group.add(e)
                                    e = Enemy_Bullet(self, self.type.attack.bullet, self.direction + math.pi/2 - math.radians(self.type.attack.spread*(a + 1)) + math.radians(random.randrange(-self.type.attack.random_spread, self.type.attack.random_spread + 1)), self.scaling)
                                    enemy_bullet_group.add(e)
                                    e = Enemy_Bullet(self, self.type.attack.bullet, self.direction + math.pi/2 + math.radians(self.type.attack.spread*(a + 1)) + math.radians(random.randrange(-self.type.attack.random_spread, self.type.attack.random_spread + 1)), self.scaling)
                                    enemy_bullet_group.add(e)

                        else:
                            e = Enemy_Bullet(self, self.type.attack.bullet, self.direction + math.radians(random.randrange(-self.type.attack.random_spread, self.type.attack.random_spread + 1)), self.scaling)
                            enemy_bullet_group.add(e)
                        if self.type.attack.type == "spiral":
                            self.direction += math.radians(self.type.attack.spread)


        else:
            if self.fireclock <= 1:
                self.fireclock = 0
            else:
                self.fireclock -= 1

        if math.hypot(self.targetx - self.rect.x, self.targety - self.rect.y) > self.type.speed * 20:

            if "dive" in self.type.behavior and (self.rect.right < 0 or self.rect.left > WIN_W * 3/2 or self.rect.top > WIN_H * 3/2 or self.rect.bottom < 0):
                self.hp = 0
                self.kill()
                self.indicator.kill()

            if math.fabs(self.rect.x - self.targetx) > self.type.speed*100:
                self.xvel += self.type.speed * (self.targetx - self.rect.x)/math.hypot(self.targetx - self.rect.x, self.targety - self.rect.y)

            elif math.fabs(self.xvel) > math.fabs(self.type.speed*10):
                if self.xvel < 0:
                    self.xvel += self.type.speed
                else:
                    self.xvel -= self.type.speed

            else:
                self.xvel += self.type.speed * ((self.targetx - self.rect.x)/math.hypot(self.targetx - self.rect.x, self.targety - self.rect.y)) / 3

            if math.fabs(self.rect.y - self.targety) > self.type.speed*100:
                self.yvel -= self.type.speed * (self.targety - self.rect.y)/math.hypot(self.targetx - self.rect.x, self.targety - self.rect.y)

            elif math.fabs(self.yvel) > math.fabs(self.type.speed*10):
                if self.yvel < 0:
                    self.yvel += self.type.speed
                else:
                    self.yvel -= self.type.speed

            else:
                self.yvel -= self.type.speed * ((self.targety - self.rect.y)/math.hypot(self.targetx - self.rect.x, self.targety - self.rect.y)) / 3
        else:
            if self.rect.colliderect(camera.rect):
                if "strafe" in self.type.behavior:
                    while math.hypot(self.targetx - self.rect.x, self.targety - self.rect.y) > self.strafe_radius or math.hypot(self.targetx - self.rect.x, self.targety - self.rect.y) < self.strafe_radius/2 or self.targetx < camera.rect.left + self.type.speed*100 or self.targetx > camera.rect.right - self.type.speed*100 or self.targety < camera.rect.top + self.type.speed*100 or self.targety > camera.rect.bottom - self.type.speed*100:
                        self.targetx = random.randrange(self.rect.x - self.strafe_radius, self.rect.x + self.strafe_radius + 1)
                        self.targety = random.randrange(self.rect.y - self.strafe_radius, self.rect.y + self.strafe_radius + 1)
                elif "snipe" in self.type.behavior:
                    self.targetx = random.randrange(self.rect.x - self.strafe_radius,
                                                    self.rect.x + self.strafe_radius + 1)
                    self.targety = random.randrange(camera.rect.top + self.basey - self.strafe_radius,
                                                    camera.rect.top + self.basey + self.strafe_radius + 1)
                    while not camera.rect.collidepoint(self.targetx, self.targety):
                        self.targetx = random.randrange(self.rect.x - self.strafe_radius, self.rect.x + self.strafe_radius + 1)
                        self.targety = random.randrange(camera.rect.top + self.basey - self.strafe_radius, camera.rect.top + self.basey + self.strafe_radius + 1)

                elif "bomb" in self.type.behavior:
                    if self.fireclock < 120:
                        self.targetx = random.randrange(self.target.rect.x - self.strafe_radius, self.target.rect.x + self.strafe_radius + 1)
                        self.targety = random.randrange(self.target.rect.y - self.strafe_radius, self.target.rect.y + self.strafe_radius + 1)
                    elif math.fabs(self.rect.y - (self.basey + camera.rect.top)) < self.strafe_radius * 1.5:
                        self.targetx = random.randrange(camera.rect.left, camera.rect.right + 1)
                        self.targety = random.randrange((self.basey + camera.rect.top) - self.strafe_radius, (self.basey + camera.rect.top) + self.strafe_radius + 1)

                    else:
                        while math.hypot(self.targetx - self.rect.x, self.targety - self.rect.y) > self.strafe_radius or math.hypot(self.targetx - self.rect.x, self.targety - self.rect.y) < self.strafe_radius / 2 or self.targetx < camera.rect.left + self.type.speed * 100 or self.targetx > camera.rect.right - self.type.speed * 100 or self.targety < camera.rect.top + self.type.speed * 100 or self.targety > camera.rect.bottom - self.type.speed * 100:
                            self.targetx = random.randrange(self.rect.x - self.strafe_radius, self.rect.x + self.strafe_radius + 1)
                            self.targety = random.randrange(self.rect.y - self.strafe_radius, self.rect.y + self.strafe_radius + 1)
            else:
                i = 1
                while math.hypot(self.targetx - self.rect.x, self.targety - self.rect.y) > self.strafe_radius * i/2 or math.hypot(self.targetx - self.rect.x, self.targety - self.rect.y) < self.strafe_radius / 2 * i/2 or self.targetx < camera.rect.left + self.type.speed * 100 or self.targetx > camera.rect.right - self.type.speed * 100 or self.targety < camera.rect.top + self.type.speed * 100 or self.targety > camera.rect.bottom - self.type.speed * 100:
                    self.targetx = random.randrange(self.rect.x - self.strafe_radius * i/2, self.rect.x + self.strafe_radius * i/2 + 1)
                    self.targety = random.randrange(self.rect.y - self.strafe_radius * i/2, self.rect.y + self.strafe_radius * i/2 + 1)
                    if self.strafe_radius * i/2 < WIN_H:
                        i += 1

        if math.fabs(math.hypot(self.xvel, self.yvel)) > self.type.speed * 20:
            self.xvel *= self.type.speed*20/math.fabs(math.hypot(self.xvel, self.yvel))
            self.yvel *= self.type.speed*20/math.fabs(math.hypot(self.xvel, self.yvel))
        self.x += self.xvel
        self.y -= self.yvel
        self.rect.x = self.x
        self.rect.y = self.y
        if math.fabs(self.xvel) < 0.01:
            self.xvel = 0
        else:
            self.xvel *= 0.98
        if math.fabs(self.yvel) < 0.01:
            self.yvel = 0
        else:
            self.yvel *= 0.98

        self.health_bar.length = (self.rect.width+self.rect.height)*self.hp/(self.type.health*2**(self.scaling+1))
        self.health_bar.rect.centerx = self.rect.centerx
        self.health_bar.rect.y = self.rect.y - 20
        self.health_bar.rect = camera.apply(self.health_bar.rect)


class Enemy_Bullet(pygame.sprite.Sprite):
    def __init__(self, spawner, enemy_bullet_type, direction, scaling=0):
        pygame.sprite.Sprite.__init__(self)
        self.type = enemy_bullet_type
        self.scaling = scaling
        if self.type.image:
            self.image = pygame.transform.scale(self.type.image, (self.type.width, self.type.height))
        else:
            self.image = pygame.Surface((self.type.width, self.type.height))
            self.image.fill(RED)
        self.rect = self.image.get_rect()
        self.rect.centerx = spawner.rect.centerx
        self.rect.centery = spawner.rect.centery
        self.direction = direction
        self.player_direction = math.atan2(self.rect.centery - spawner.target.rect.centery, spawner.target.rect.centerx - self.rect.centerx)
        self.spawner = spawner
        if type(self.type.speed) != str:
            self.speed = self.type.speed
        else:
            self.speed = float(self.type.speed[0:self.type.speed.find(";")])
        if self.type.accel == False:
            self.xvel = math.cos(direction) * self.speed
            self.yvel = math.sin(direction) * self.speed
        else:
            if type(self.type.accel) == int:
                self.xvel = math.cos(direction) * self.type.accel
                self.yvel = math.sin(direction) * self.type.accel
            else:
                speed = int(self.type.accel[0:self.type.accel.find(";")]) + random.randrange(-int(self.type.accel[self.type.accel.find(";") + 1:-1]), int(self.type.accel[self.type.accel.find(";") + 1:-1]) + 1)
                self.xvel = math.cos(direction) * speed
                self.yvel = math.sin(direction) * speed
        self.x = self.rect.x
        self.y = self.rect.y
        if type(self.type.delay) == int:
            self.fuse = self.type.delay
        else:
            self.fuse = int(self.type.delay[0:self.type.delay.find(";")]) + random.randrange(-int(self.type.delay[self.type.delay.find(";") + 1:-1]), int(self.type.delay[self.type.delay.find(";") + 1:-1]) + 1)
        self.target = spawner.target

    def update(self):
        if not self.target or self.target.hp <= 0:
            d = 9999
            for a in ally_group:
                new_d = math.hypot(self.rect.centerx - a.rect.centerx, self.rect.centery - a.rect.centery)
                if new_d < d:
                    d = new_d
                    self.target = a
            for s in ship_group:
                new_d = math.hypot(self.rect.centerx - s.rect.centerx, self.rect.centery - s.rect.centery)
                if new_d < d:
                    d = new_d
                    self.target = s
        if self.fuse == 0:
            if self.direction < -math.pi:
                self.direction += 2 * math.pi
            if self.direction > math.pi:
                self.direction -= 2 * math.pi
            if self.type.homing_speed > 0:
                player_direction = math.atan2(self.rect.centery - self.target.rect.centery,
                                              self.target.rect.centerx - self.rect.centerx)
                if self.direction >= 0:
                    if player_direction > self.direction or player_direction < self.direction - math.pi:
                        self.direction += math.radians(self.type.homing_speed) / 60
                    else:
                        self.direction -= math.radians(self.type.homing_speed) / 60
                else:
                    if player_direction > self.direction and player_direction < self.direction + math.pi:
                        self.direction += math.radians(self.type.homing_speed) / 60
                    else:
                        self.direction -= math.radians(self.type.homing_speed) / 60

            if self.type.accel:
                self.xvel += math.cos(self.direction) * self.speed
                self.yvel += math.sin(self.direction) * self.speed
            else:
                self.xvel = math.cos(self.direction) * self.speed
                self.yvel = math.sin(self.direction) * self.speed

        else:
            player_direction = math.atan2(self.rect.centery - self.target.rect.centery,
                                          self.target.rect.centerx - self.rect.centerx)
            if self.type.homing_speed:
                if self.type.accel != False:
                    if self.direction >= 0:
                        if player_direction > self.direction or player_direction < self.direction - math.pi:
                            self.direction += math.radians(self.type.homing_speed) / 60
                        else:
                            self.direction -= math.radians(self.type.homing_speed) / 60
                    else:
                        if player_direction > self.direction and player_direction < self.direction + math.pi:
                            self.direction += math.radians(self.type.homing_speed) / 60
                        else:
                            self.direction -= math.radians(self.type.homing_speed) / 60
            self.fuse -= 1
            if self.type.homing_speed:
                if self.fuse == 0:
                    if self.type.accel != False:
                        if type(self.type.homing_speed) == str:
                            self.direction = self.player_direction + math.radians(
                                random.randrange(-self.type.spread, self.type.spread + 1))
                        else:
                            self.direction = math.atan2(self.spawner.rect.centery - self.target.rect.centery,
                                                        self.target.rect.centerx - self.spawner.rect.centerx) + math.radians(
                                random.randrange(-self.type.spread, self.type.spread + 1))
            if math.fabs(self.xvel) < 0.01:
                self.xvel = 0
            else:
                self.xvel *= 0.95
            if math.fabs(self.yvel) < 0.01:
                self.yvel = 0
            else:
                self.yvel *= 0.95

        if type(self.type.speed) != str:
            self.xvel *= 0.995
        else:
            self.xvel *= float(self.type.speed[self.type.speed.find(";") + 1: -1])

        if type(self.type.speed) != str:
            self.yvel *= 0.995
        else:
            self.yvel *= float(self.type.speed[self.type.speed.find(";") + 1: -1])
        self.x += self.xvel
        self.y -= self.yvel
        self.rect.x = self.x
        self.rect.y = self.y
        for s in ship_group:
            if self.rect.colliderect(s.rect):
                if s.type.max_shield:
                    if s.shield_active:
                        s.shield -= self.type.damage*2**self.scaling
                        if self.type.damage > s.type.shield_def_abs*2**s.type.level:
                            s.hp -= (self.type.damage*2**self.scaling - s.type.shield_def_abs) * (1 - s.type.shield_def_mult)
                    else:
                        s.hp -= self.type.damage*2**self.scaling
                else:
                    s.hp -= self.type.damage * 2 ** self.scaling
                s.regen_timer = 30
                self.kill()

        for a in ally_group:
            if self.rect.colliderect(a.rect):
                a.hp -= self.type.damage
                if a.hp <= 0:
                    a.kill()
                self.kill()

        if self.rect.x < 0 or self.rect.x > WIN_W * 3 / 2 or self.rect.y < 0 or self.rect.y > WIN_H * 3 / 2:
            self.kill()


class Enemy_Indicator(pygame.sprite.Sprite):
    def __init__(self, target):
        pygame.sprite.Sprite.__init__(self)
        self.target = target
        self.orig_image = pygame.image.load("image/RightArrow.png")
        self.orig_image.set_colorkey(WHITE)
        self.direction = 0
        self.image = pygame.transform.scale(self.orig_image, (15, 30))
        self.rect = self.image.get_rect()
        self.display = False
        self.size = 15

    def update(self, camera):
        if self.target.rect.colliderect(camera.rect):
            self.display = False
        else:
            self.size = 3000/(math.hypot(self.target.rect.centerx - camera.rect.centerx, camera.rect.centery - self.target.rect.centery) - 200)
            self.image = pygame.transform.scale(self.orig_image, (self.size, self.size * 2))
            self.rect = self.image.get_rect()
            self.display = True
            self.direction = math.atan2(camera.rect.centery - self.target.rect.centery, self.target.rect.centerx - camera.rect.centerx)
            if self.direction > math.atan2(-WIN_H, WIN_W) and self.direction < math.atan2(WIN_H, WIN_W):
                self.rect.centerx = camera.rect.right - 30
                self.rect.centery = camera.rect.centery + (self.target.rect.centery - camera.rect.centery) * math.fabs((camera.rect.right - 30 - camera.rect.centerx) / (self.target.rect.centerx - camera.rect.centerx))
            elif self.direction > math.atan2(WIN_H, WIN_W) and self.direction < math.atan2(WIN_H, -WIN_W):
                self.rect.centerx = camera.rect.centerx + (self.target.rect.centerx - camera.rect.centerx) * math.fabs((camera.rect.top + 30 - camera.rect.centery) / (self.target.rect.centery - camera.rect.centery))
                self.rect.centery = camera.rect.top + 30
            elif self.direction > math.atan2(WIN_H, -WIN_W) or self.direction < math.atan2(-WIN_H, -WIN_W):
                self.rect.centerx = camera.rect.left + 30
                self.rect.centery = camera.rect.centery + (self.target.rect.centery - camera.rect.centery) * math.fabs((camera.rect.left + 30 - camera.rect.centerx) / (self.target.rect.centerx - camera.rect.centerx))
            elif self.direction > math.atan2(-WIN_H, -WIN_W) and self.direction < math.atan2(-WIN_H, WIN_W):
                self.rect.centerx = camera.rect.centerx + (self.target.rect.centerx - camera.rect.centerx) * math.fabs((camera.rect.bottom - 30 - camera.rect.centery) / (self.target.rect.centery - camera.rect.centery))
                self.rect.centery = camera.rect.bottom - 30


class Bar(pygame.sprite.Sprite):
    def __init__(self, x, y, color, markers, text, length=150, height=15, screen=None):
        pygame.sprite.Sprite.__init__(self)
        self.max_length = length
        self.length = self.max_length
        self.height = height
        self.image = pygame.Surface((self.length, self.height))
        self.rect = self.image.get_rect()
        self.color = color
        self.image.fill(self.color)
        self.rect.x = x
        self.rect.y = y
        self.markers = markers
        if text:
            if type(text) == str:
                self.text = Text(17, " ", WHITE, x + 1, y + 1, 0)
                self.text.text = text
            else:
                self.text = Text(17, " ", WHITE, x + 1, y + 1, 0)
            text_group.add(self.text)
        else:
            self.text = False
        self.screen = screen

    def update(self, screen):
        self.image = pygame.transform.scale(self.image, (self.length, self.height))
        self.image.fill(self.color)


class Background_Star(pygame.sprite.Sprite):
    def __init__(self, image, y=-WIN_H/2):
        self.dist = random.randrange(5, 15)

        pygame.sprite.Sprite.__init__(self)
        if image:
            self.image = image
        else:
            self.image = pygame.Surface((10, 10))
            self.image.fill(WHITE)
        self.image = pygame.transform.scale(self.image, (15/self.dist, 15/self.dist))
        self.rect = self.image.get_rect()
        self.rect.centerx = random.randrange(-WIN_W/2, WIN_W*3/4)
        self.rect.centery = y
        self.y = self.rect.y

    def update(self):
        self.y += 2/self.dist
        self.rect.y = self.y
        if self.y > WIN_H:
            self.kill()


    def apply_camera(self, camera):
        return (self.rect.move(WIN_W/2 - camera.rect.centerx/self.dist, WIN_H/2 - camera.rect.centery/self.dist))

class Camera(object):
    def __init__(self):
        self.rect = pygame.Rect(WIN_W/2, WIN_H, WIN_W, WIN_H)

    def update(self, player):
#        if player.rect.centerx <= WIN_W/4:
#            self.rect.centerx = WIN_W/2
#        elif player.rect.centerx >= WIN_W*5/4:
#            self.rect.centerx = WIN_W
#        else:
#            self.rect.centerx = (player.rect.centerx - WIN_W/4)/2 + WIN_W/2
#
#        if player.rect.centery <= WIN_H/4:
#            self.rect.centery = WIN_H/2
#        elif player.rect.centery >= WIN_H*5/4:
#            self.rect.centery = WIN_H
#        else:
#            self.rect.centery = (player.rect.centery - WIN_H/4)/2 + WIN_H/2
        self.rect.centerx = WIN_W*3/4
        self.rect.centery = WIN_H*3/4

    def apply(self, target_rect):
        return (target_rect.move(WIN_W/2 - self.rect.centerx, WIN_H/2 - self.rect.centery))


class Text(pygame.sprite.Sprite):
    def __init__(self, size, text, color, xpos, ypos, align, size_limit=False):
        pygame.sprite.Sprite.__init__(self)
        self.xpos = xpos
        self.ypos = ypos
        self.font = pygame.font.SysFont("Britannic Bold", size)
        self.color = color
        self.image = self.font.render(text, 1, color)
        self.rect = self.image.get_rect()
        self.rect = self.rect.move(xpos - self.rect.width/2, ypos - self.rect.height/2)
        self.text = text
        self.align = align
        self.size_limit = size_limit

    def update(self):
        self.image = self.font.render(self.text, 1, self.color)
        self.rect = self.image.get_rect()
        if self.align == 1:
            self.rect = self.rect.move(self.xpos - self.rect.width/2, self.ypos - self.rect.height/2)
        elif self.align == 2:
            self.rect = self.rect.move(self.xpos - self.rect.width, self.ypos - self.rect.height/2)
        else:
            self.rect = self.rect.move(self.xpos, self.ypos)

class Game():
    def __init__(self):
        self.menu = True
        self.play = False
        self.tech_tree_open = False
        self.tech_tree_popup = False
        self.player = None
        self.selected_ship = None
        self.points = 0
        self.time = 0
        self.unlock_all_cost = 0

class Tech_Tree_Popup(object):
    def __init__(self, width, height, image=None):
        if image:
            self.image = pygame.transform.scale(image, (width, height))
        else:
            self.image = pygame.Surface((width, height))
            self.image.fill(LIGHT_GREY)
        self.rect = self.image.get_rect()
        self.rect.centerx = WIN_W/2
        self.rect.centery = WIN_H/2

def blit_rot_center(image, angle, rect, screen):
    rotated_image = pygame.transform.rotate(image, angle)
    new_rect = rotated_image.get_rect(center=image.get_rect(center=(rect.centerx, rect.centery)).center)
    screen.blit(rotated_image, new_rect)

def blit_text(surface, text, pos, font, screen, color=pygame.Color('black')):
    words = [word.split(' ') for word in text.splitlines()]  # 2D array where each row is a list of words.
    space = font.size(' ')[0]  # The width of a space.
    max_width, max_height = surface.get_size()
    x, y = pos
    for line in words:
        for word in line:
            word_surface = font.render(word, 0, color)
            word_width, word_height = word_surface.get_size()
            if x + word_width >= max_width:
                x = pos[0]  # Reset the x.
                y += word_height  # Start on new row.
            surface.blit(word_surface, (x, y))
            x += word_width + space
        x = pos[0]  # Reset the x.
        y += word_height  # Start on new row.

def main():
    pygame.init()

    # Create Game Variables
    clock = pygame.time.Clock()

    pygame.display.set_caption("It's not a bullet hell if you don't wish you hadn't been born")
    screen = pygame.display.set_mode((WIN_W, WIN_H), pygame.SRCALPHA)

    popup_text = ""


    play_button = Button(WIN_W/2, WIN_H/2, WIN_W/3, WIN_H/10, screen="menu")
    unlock_button = Button(WIN_W/2, WIN_H*2/3, WIN_W/2, WIN_H/20, screen="tech_tree_popup", text="unlock")
    unlock_all_button = Button(WIN_W/2, WIN_H*3/4, WIN_W/2, WIN_H/20, screen="tech_tree_popup", text="Unlock Tree")
    select_button = Button(WIN_W/2, WIN_H*2/3, WIN_W/2, WIN_H/20, screen="tech_tree_popup", text="Select")
    upgrade_button = Button(WIN_W/2, WIN_H*3/4, WIN_W/2, WIN_H/20, screen="tech_tree_popup", text="upgrade")
    exit_popup_button = Button(WIN_W*5/6, WIN_H/6, WIN_W/30, WIN_H/40, screen="tech_tree_popup")

    tech_tree_popup = Tech_Tree_Popup(WIN_W*2/3, WIN_H*2/3)

    button_group.add(play_button, unlock_all_button)
    camera = Camera()
    generate_tech_tree()


    while True:
        play_button.activate = False
        play_button.display = True
        while game.menu:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()

            for b in button_group:
                if (b.screen == None or b.screen == "menu") and b.display:
                    b.update()

            if play_button.activate or pygame.key.get_pressed()[pygame.K_RETURN]:
                game.menu = False
                game.play = True
                play_button.display = False

            screen.fill(BLACK)
            for b in button_group:
                if (b.screen == None or b.screen == "menu") and b.display:
                    screen.blit(b.image, b.rect)

            pygame.display.flip()
            clock.tick(fps)

        player = Ship(basic_ship, WIN_W*3/4, WIN_H)
        ship_group.add(player)
        game.player = player
        camera.update(game.player)


        for i in range(star_spawnrate*15):
            s = Background_Star(False, y=random.randrange(-WIN_H/2, WIN_H/2))
            star_group.add(s)

        fps_text = Text(30, "", BLACK, 60, 30, 1)
        points_text = Text(30, "", LIGHT_BLUE, WIN_W - 10, 30, 2)
        scaling_text = Text(30, "", RED, WIN_W / 2, 30, 1)
        text_group.add(fps_text, points_text, scaling_text)

        game.tech_tree_open = False
        e_down = False
        game.time = 0

        while game.play:
            game.time += 1
            scaling_text.text = str(round(game.time/4000, 2))
            scaling_text.update()
            if game.tech_tree_open:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        sys.exit()
                if pygame.key.get_pressed()[pygame.K_e]:
                    if not e_down:
                        game.tech_tree_open = False
                        e_down = True
                else:
                    e_down = False

                screen.fill(BLACK)
                points_text.text = "Points: " + str(game.points)
                points_text.update()
                screen.blit(points_text.image, points_text.rect)
                for node in tech_tree.all_nodes():
                    if node.data.level:
                        for child in tech_tree.children(node.identifier):
                            pygame.draw.line(screen, LIGHTER_GREY, node.data.button.rect.center, child.data.button.rect.center, width=4)
                    else:
                        for child in tech_tree.children(node.identifier):
                            pygame.draw.line(screen, LIGHT_GREY, node.data.button.rect.center, child.data.button.rect.center, width=3)
                if not game.tech_tree_popup:
                    for b in button_group:
                        if (b.screen == None or b.screen == "tech_tree") and b.display:
                            b.update()
                            if b.activate:
                                game.tech_tree_popup = True
                                game.selected_ship = b.data.data
                                unlock_button.text.text = "Unlock " + b.data.tag + " - " + str(b.data.data.points_cost)
                                unlock_button.text.update()
                                if game.selected_ship.level < 3:
                                    upgrade_button.text.text = "Upgrade " + game.selected_ship.node.tag + " - " + str(round(b.data.data.points_cost*2**game.selected_ship.level))
                                else:
                                    upgrade_button.text.text = "MAX LEVEL"
                                upgrade_button.text.update()
                                if game.selected_ship.description_text:
                                    popup_text = game.selected_ship.description_text
                                else:
                                    popup_text = "no description"
                                for b in bar_group:
                                    if b.screen == "tech_tree_popup":
                                        b.text.kill()
                                        b.kill()
                                level_display_bar = Bar(WIN_W / 5, WIN_H / 5, GREEN, 1, " ", length=200, height=12, screen="tech_tree_popup")
                                level_display_bar.length = game.selected_ship.level * 25
                                start_level_display_bar = Bar(WIN_W / 5, WIN_H / 5, DARK_GREEN, 1, "Level", length=200, height=12, screen="tech_tree_popup")
                                start_level_display_bar.length = game.selected_ship.start_level * 25
                                start_level_display_bar.text.color = BLACK
                                hp_display_bar = Bar(WIN_W / 5, WIN_H / 5 + WIN_H / 40, RED, 1, "Health",
                                                     length=100, height=12, screen="tech_tree_popup")
                                hp_display_bar.length = game.selected_ship.max_health * 3
                                hp_regen_display_bar = Bar(WIN_W / 5, WIN_H / 5 + 2 * WIN_H / 40, RED, 1, "Health Regen",
                                                     length=100, height=12, screen="tech_tree_popup")
                                hp_regen_display_bar.length = game.selected_ship.health_regen * 500
                                shield_display_bar = Bar(WIN_W / 5, WIN_H / 5 + 3 * WIN_H / 40, BLUE, 1,
                                                         "Shield", length=100, height=12, screen="tech_tree_popup")
                                shield_regen_display_bar = Bar(WIN_W / 5, WIN_H / 5 + 4 * WIN_H / 40, BLUE, 1,
                                                               "Shield", length=100, height=12,
                                                               screen="tech_tree_popup")
                                speed_display_bar = Bar(WIN_W / 5, WIN_H / 5 + 5 * WIN_H / 40, YELLOW, 1,
                                                               "Speed", length=100, height=12,
                                                               screen="tech_tree_popup")
                                speed_display_bar.length = game.selected_ship.speed * 6
                                speed_display_bar.text.color = BLACK
                                turn_speed_display_bar = Bar(WIN_W / 5, WIN_H / 5 + 6 * WIN_H / 40, YELLOW, 1,
                                                               "Turn Speed", length=100, height=12,
                                                               screen="tech_tree_popup")
                                turn_speed_display_bar.length = game.selected_ship.turn_speed / 7.2
                                turn_speed_display_bar.text.color = BLACK
                                if game.selected_ship.max_shield:
                                    shield_display_bar.length = game.selected_ship.max_shield * 3
                                    shield_regen_display_bar.length = game.selected_ship.shield_regen * 500
                                else:
                                    shield_display_bar.length = 0
                                    shield_display_bar.text.text = "No Shield"
                                    shield_regen_display_bar.length = 0
                                    shield_regen_display_bar.text.text = "No Shield"
                                bar_group.add(hp_display_bar, hp_regen_display_bar, shield_display_bar, shield_regen_display_bar, level_display_bar, start_level_display_bar, speed_display_bar, turn_speed_display_bar)

                                if "spawn" not in game.selected_ship.attack_1.type:
                                    attack_1_damage_display_bar = Bar(WIN_W / 4 + 100, WIN_H / 4, ORANGE, 1, "Damage",
                                                                      length=60, height=12,
                                                                      screen="tech_tree_popup")
                                    attack_1_firerate_display_bar = Bar(WIN_W / 4 + 100, WIN_H / 4 + WIN_H / 40, ORANGE,
                                                                        1, "Firerate", length=60,
                                                                        height=12, screen="tech_tree_popup")
                                    if "laser" in game.selected_ship.attack_1.type:
                                        attack_1_firerate_display_bar.length = math.sqrt(
                                            game.selected_ship.attack_1.firerate) * 6
                                        attack_1_damage_display_bar.length = math.sqrt(
                                            float(game.selected_ship.attack_1.type[5:-1])) * 8
                                    else:
                                        attack_1_firerate_display_bar.length = math.sqrt(
                                            60 / (
                                                        60 / game.selected_ship.attack_1.firerate + game.selected_ship.attack_1.cooldown)) * 6
                                        attack_1_damage_display_bar.length = game.selected_ship.attack_1.bullet.damage * 2

                                    attack_1_ammo_display_bar = Bar(WIN_W / 4 + 100, WIN_H / 4 + 2 * WIN_H / 40, ORANGE,
                                                                    1,
                                                                    "Capacity", length=60, height=12,
                                                                    screen="tech_tree_popup")
                                    attack_1_ammo_display_bar.length = math.sqrt(game.selected_ship.attack_1.volley) * 3
                                else:
                                    attack_1_health_display_bar = Bar(WIN_W / 4 + 100, WIN_H / 4, ORANGE,
                                                                      1, "Health", length=60, height=12,
                                                                      screen="tech_tree_popup")
                                    attack_1_firerate_display_bar = Bar(WIN_W / 4 + 100, WIN_H / 4 + 2 * WIN_H / 40,
                                                                        ORANGE, 1, "Firerate", length=60,
                                                                        height=12, screen="tech_tree_popup")
                                    attack_1_damage_display_bar = Bar(WIN_W / 4 + 100, WIN_H / 4 + WIN_H / 40, ORANGE,
                                                                      1, "Damage", length=60, height=12,
                                                                      screen="tech_tree_popup")
                                    if "laser" in game.selected_ship.attack_1.bullet.attack.type:
                                        attack_1_firerate_display_bar.length = math.sqrt(
                                            game.selected_ship.attack_1.bullet.attack.firerate) * 6
                                        attack_1_damage_display_bar.length = math.sqrt(
                                            float(game.selected_ship.attack_1.bullet.attack[5:-1])) * 8
                                    else:
                                        attack_1_firerate_display_bar.length = math.sqrt(60 / (
                                                60 / game.selected_ship.attack_1.bullet.attack.firerate + game.selected_ship.attack_1.bullet.attack.cooldown)) * 6
                                        attack_1_damage_display_bar.length = game.selected_ship.attack_1.bullet.attack.bullet.damage * 2
                                    attack_1_firerate_display_bar = Bar(WIN_W / 4 + 100, WIN_H / 4 + 2 * WIN_H / 40,
                                                                        ORANGE, 1, "Firerate", length=60,
                                                                        height=12, screen="tech_tree_popup")

                                    attack_1_ammo_display_bar = Bar(WIN_W / 4 + 100, WIN_H / 4 + 3 * WIN_H / 40, ORANGE,
                                                                    1,
                                                                    "Capacity", length=60, height=12,
                                                                    screen="tech_tree_popup")
                                    attack_1_ammo_display_bar.length = math.sqrt(
                                        game.selected_ship.attack_1.bullet.attack.volley) * 3
                                    attack_1_max_spawned_display_bar = Bar(WIN_W / 4 + 100, WIN_H / 4 + 4 * WIN_H / 40,
                                                                           ORANGE, 1, "Max Spawn", length=60,
                                                                           height=12, screen="tech_tree_popup")
                                    attack_1_max_spawned_display_bar.length = int(
                                        game.selected_ship.attack_1.type[5:-1]) * 10
                                    bar_group.add(attack_1_health_display_bar, attack_1_max_spawned_display_bar)
                                bar_group.add(attack_1_damage_display_bar,
                                              attack_1_firerate_display_bar, attack_1_ammo_display_bar)

                                if game.selected_ship.attack_2:
                                    if "spawn" not in game.selected_ship.attack_2.type:
                                        attack_2_damage_display_bar = Bar(WIN_W / 4 + 180, WIN_H / 4, ORANGE, 1, "Damage",
                                                                          length=60, height=12,
                                                                          screen="tech_tree_popup")
                                        attack_2_firerate_display_bar = Bar(WIN_W / 4 + 180, WIN_H / 4 + WIN_H / 40, ORANGE,
                                                                            1, "Firerate", length=60,
                                                                            height=12, screen="tech_tree_popup")
                                        if "laser" in game.selected_ship.attack_2.type:
                                            attack_2_firerate_display_bar.length = math.sqrt(
                                                game.selected_ship.attack_2.firerate) * 6
                                            attack_2_damage_display_bar.length = math.sqrt(
                                                float(game.selected_ship.attack_2.type[5:-1])) * 8
                                        else:
                                            attack_2_firerate_display_bar.length = math.sqrt(
                                                60 / (
                                                            60 / game.selected_ship.attack_2.firerate + game.selected_ship.attack_2.cooldown)) * 6
                                            attack_2_damage_display_bar.length = game.selected_ship.attack_2.bullet.damage * 2

                                        attack_2_ammo_display_bar = Bar(WIN_W / 4 + 180, WIN_H / 4 + 2 * WIN_H / 40, ORANGE,
                                                                        1,
                                                                        "Capacity", length=60, height=12,
                                                                        screen="tech_tree_popup")
                                        attack_2_ammo_display_bar.length = math.sqrt(game.selected_ship.attack_2.volley) * 3
                                    else:
                                        attack_2_health_display_bar = Bar(WIN_W / 4 + 180, WIN_H / 4, ORANGE,
                                                                          1, "Health", length=60, height=12,
                                                                          screen="tech_tree_popup")
                                        attack_2_firerate_display_bar = Bar(WIN_W / 4 + 180, WIN_H / 4 + 2 * WIN_H / 40,
                                                                            ORANGE, 1, "Firerate", length=60,
                                                                            height=12, screen="tech_tree_popup")
                                        attack_2_damage_display_bar = Bar(WIN_W / 4 + 180, WIN_H / 4 + WIN_H / 40, ORANGE,
                                                                          1, "Damage", length=60, height=12,
                                                                          screen="tech_tree_popup")
                                        if "laser" in game.selected_ship.attack_2.bullet.attack.type:
                                            attack_2_firerate_display_bar.length = math.sqrt(
                                                game.selected_ship.attack_2.bullet.attack.firerate) * 6
                                            attack_2_damage_display_bar.length = math.sqrt(
                                                float(game.selected_ship.attack_2.bullet.attack[5:-1])) * 8
                                        else:
                                            attack_2_firerate_display_bar.length = math.sqrt(60 / (
                                                    60 / game.selected_ship.attack_2.bullet.attack.firerate + game.selected_ship.attack_2.bullet.attack.cooldown)) * 6
                                            attack_2_damage_display_bar.length = game.selected_ship.attack_2.bullet.attack.bullet.damage * 2

                                        attack_2_ammo_display_bar = Bar(WIN_W / 4 + 180, WIN_H / 4 + 3 * WIN_H / 40, ORANGE,
                                                                        1,
                                                                        "Capacity", length=60, height=12,
                                                                        screen="tech_tree_popup")
                                        attack_2_ammo_display_bar.length = math.sqrt(
                                            game.selected_ship.attack_2.bullet.attack.volley) * 3
                                        attack_2_max_spawned_display_bar = Bar(WIN_W / 4 + 180, WIN_H / 4 + 4 * WIN_H / 40,
                                                                               ORANGE, 1, "Max Spawn", length=60,
                                                                               height=12, screen="tech_tree_popup")
                                        attack_2_max_spawned_display_bar.length = int(
                                            game.selected_ship.attack_2.type[5:-1]) * 10
                                        bar_group.add(attack_2_health_display_bar, attack_2_max_spawned_display_bar)
                                    bar_group.add(attack_2_damage_display_bar,
                                                  attack_2_firerate_display_bar, attack_2_ammo_display_bar)
                                if game.selected_ship.attack_3:
                                    if "spawn" not in game.selected_ship.attack_3.type:
                                        attack_3_damage_display_bar = Bar(WIN_W / 4 + 260, WIN_H / 4, ORANGE, 1, "Damage",
                                                                          length=60, height=12,
                                                                          screen="tech_tree_popup")
                                        attack_3_firerate_display_bar = Bar(WIN_W / 4 + 260, WIN_H / 4 + WIN_H / 40, ORANGE,
                                                                            1, "Firerate", length=60,
                                                                            height=12, screen="tech_tree_popup")
                                        if "laser" in game.selected_ship.attack_3.type:
                                            attack_3_firerate_display_bar.length = math.sqrt(
                                                game.selected_ship.attack_3.firerate) * 6
                                            attack_3_damage_display_bar.length = math.sqrt(
                                                float(game.selected_ship.attack_3.type[5:-1])) * 8
                                        else:
                                            attack_3_firerate_display_bar.length = math.sqrt(
                                                60 / (
                                                            60 / game.selected_ship.attack_3.firerate + game.selected_ship.attack_3.cooldown)) * 6
                                            attack_3_damage_display_bar.length = game.selected_ship.attack_3.bullet.damage * 2

                                        attack_3_ammo_display_bar = Bar(WIN_W / 4 + 260, WIN_H / 4 + 2 * WIN_H / 40, ORANGE,
                                                                        1,
                                                                        "Capacity", length=60, height=12,
                                                                        screen="tech_tree_popup")
                                        attack_3_ammo_display_bar.length = math.sqrt(game.selected_ship.attack_3.volley) * 3
                                    else:
                                        attack_3_health_display_bar = Bar(WIN_W / 4 + 260, WIN_H / 4, ORANGE,
                                                                          1, "Health", length=60, height=12,
                                                                          screen="tech_tree_popup")
                                        attack_3_firerate_display_bar = Bar(WIN_W / 4 + 260, WIN_H / 4 + 2 * WIN_H / 40,
                                                                            ORANGE, 1, "Firerate", length=60,
                                                                            height=12, screen="tech_tree_popup")
                                        attack_3_damage_display_bar = Bar(WIN_W / 4 + 260, WIN_H / 4 + WIN_H / 40, ORANGE,
                                                                          1, "Damage", length=60, height=12,
                                                                          screen="tech_tree_popup")
                                        if "laser" in game.selected_ship.attack_3.bullet.attack.type:
                                            attack_3_firerate_display_bar.length = math.sqrt(
                                                game.selected_ship.attack_3.bullet.attack.firerate) * 6
                                            attack_3_damage_display_bar.length = math.sqrt(
                                                float(game.selected_ship.attack_3.bullet.attack[5:-1])) * 8
                                        else:
                                            attack_3_firerate_display_bar.length = math.sqrt(60 / (
                                                    60 / game.selected_ship.attack_3.bullet.attack.firerate + game.selected_ship.attack_3.bullet.attack.cooldown)) * 6
                                            attack_3_damage_display_bar.length = game.selected_ship.attack_3.bullet.attack.bullet.damage * 2

                                        attack_3_ammo_display_bar = Bar(WIN_W / 4 + 260, WIN_H / 4 + 3 * WIN_H / 40, ORANGE,
                                                                        1,
                                                                        "Capacity", length=60, height=12,
                                                                        screen="tech_tree_popup")
                                        attack_3_ammo_display_bar.length = math.sqrt(
                                            game.selected_ship.attack_3.bullet.attack.volley) * 3
                                        attack_3_max_spawned_display_bar = Bar(WIN_W / 4 + 260, WIN_H / 4 + 4 * WIN_H / 40,
                                                                               ORANGE, 1, "Max Spawn", length=60,
                                                                               height=12, screen="tech_tree_popup")
                                        attack_3_max_spawned_display_bar.length = int(
                                            game.selected_ship.attack_3.type[5:-1]) * 10
                                        bar_group.add(attack_3_health_display_bar, attack_3_max_spawned_display_bar)
                                    bar_group.add(attack_3_damage_display_bar,
                                                  attack_3_firerate_display_bar, attack_3_ammo_display_bar)
                                game.unlock_all_cost = 0
                                node = game.selected_ship.node
                                while node.identifier != tech_tree.root:
                                    if not node.data.level:
                                        game.unlock_all_cost += node.data.points_cost
                                        node = tech_tree.parent(node.identifier)
                                    else:
                                        break
                                unlock_all_button.text.text = "Unlock All - " + str(game.unlock_all_cost)
                                unlock_all_button.text.update()

                for b in button_group:
                    if (b.screen == None or b.screen == "tech_tree") and b.display:
                        screen.blit(b.image, pygame.Rect(b.rect.x + (b.rect.width-b.image.get_rect().width)/2, b.rect.y, 1, 1))

                if game.tech_tree_popup:
                    screen.blit(tech_tree_popup.image, tech_tree_popup.rect)
                    tech_tree_popup.image.fill(LIGHT_GREY)
                    if not unlock_button.rect.collidepoint(pygame.mouse.get_pos()):
                        unlock_button.text.update()
                    if not upgrade_button.rect.collidepoint(pygame.mouse.get_pos()):
                        upgrade_button.text.update()
                    if not select_button.rect.collidepoint(pygame.mouse.get_pos()):
                        select_button.text.update()
                    exit_popup_button.update()
                    if exit_popup_button.activate:
                        game.tech_tree_popup = False
                    screen.blit(exit_popup_button.image, exit_popup_button.rect)
                    if game.selected_ship.level == False:
                        unlock_button.display = True
                        select_button.display = False
                        unlock_all_button.display = True
                        unlock_button.update()
                        unlock_all_button.update()
                        if unlock_button.activate:
                            if tech_tree.parent(game.selected_ship.node.identifier).data.level:
                                if game.points >= game.selected_ship.points_cost:
                                    game.points -= game.selected_ship.points_cost
                                    game.selected_ship.level = game.selected_ship.start_level
                                    unlock_button.display = False
                                    select_button.display = True
                                    upgrade_button.text.text = "Upgrade " + game.selected_ship.node.tag + " - " + str(round(game.selected_ship.points_cost * 2 ** (game.selected_ship.level + 1 - game.selected_ship.start_level)))
                                    upgrade_button.text.update()
                                    bars_list = [game.player.ammo_1_bar, game.player.hp_bar]
                                    if game.player.type.max_shield:
                                        bars_list.append(game.player.shield_bar)
                                    if game.player.type.attack_2:
                                        bars_list.append(game.player.ammo_2_bar)
                                        if game.player.type.attack_3:
                                            bars_list.append(game.player.ammo_3_bar)
                                    for b in bars_list:
                                        if b.text:
                                            b.text.kill()
                                        b.kill()
                                    for b in bullet_group:
                                        b.kill()
                                    for a in ally_group:
                                        a.kill()
                                    p = Ship(game.selected_ship, game.player.rect.centerx, game.player.rect.centery)
                                    ship_group.add(p)
                                    p.hp = (game.player.hp / (game.player.type.max_health * 2 ** (
                                                game.player.type.level - 1))) * p.type.max_health * 2 ** (
                                                       p.type.level - 1)
                                    if p.type.max_shield and game.player.type.max_shield:
                                        p.shield = game.player.shield / (game.player.type.max_shield * 2 ** (
                                                    game.player.type.level - 1)) * p.type.max_shield * 2 ** (
                                                                                     p.type.level - 1)
                                    game.player.kill()
                                    game.player = p
                                    for e in enemy_group:
                                        e.target = game.player

                                else:
                                    unlock_button.text.text = "NOT ENOUGH POINTS"
                                    unlock_button.text.update()
                                    unlock_button.text.text = "Unlock " + game.selected_ship.node.tag + " - " + str(game.selected_ship.points_cost)
                            else:
                                unlock_button.text.text = "UNLOCK PREVIOUS SHIP FIRST"
                                unlock_button.text.update()
                                unlock_button.text.text = "Unlock " + game.selected_ship.node.tag + " - " + str(game.selected_ship.points_cost)
                        if unlock_all_button.activate:
                            if game.points >= game.unlock_all_cost:
                                game.points -= game.unlock_all_cost
                                node = game.selected_ship.node
                                while node.identifier != tech_tree.root:
                                    if not node.data.level:
                                        node.data.level = node.data.start_level
                                        node = tech_tree.parent(node.identifier)
                                    else:
                                        break
                                unlock_button.display = False
                                select_button.display = True
                                unlock_all_button.display = False
                                upgrade_button.text.text = "Upgrade " + game.selected_ship.node.tag + " - " + str(round(game.selected_ship.points_cost * 2 ** (game.selected_ship.level + 1 - game.selected_ship.start_level)))
                                upgrade_button.text.update()
                                bars_list = [game.player.ammo_1_bar, game.player.hp_bar]
                                if game.player.type.max_shield:
                                    bars_list.append(game.player.shield_bar)
                                if game.player.type.attack_2:
                                    bars_list.append(game.player.ammo_2_bar)
                                    if game.player.type.attack_3:
                                        bars_list.append(game.player.ammo_3_bar)
                                for b in bars_list:
                                    if b.text:
                                        b.text.kill()
                                    b.kill()
                                for b in bullet_group:
                                    b.kill()
                                for a in ally_group:
                                    a.kill()
                                p = Ship(game.selected_ship, game.player.rect.centerx, game.player.rect.centery)
                                ship_group.add(p)
                                p.hp = (game.player.hp / (game.player.type.max_health * 2 ** (
                                        game.player.type.level - 1))) * p.type.max_health * 2 ** (
                                               p.type.level - 1)
                                if p.type.max_shield and game.player.type.max_shield:
                                    p.shield = game.player.shield / (game.player.type.max_shield * 2 ** (
                                            game.player.type.level - 1)) * p.type.max_shield * 2 ** (
                                                       p.type.level - 1)

                                game.player.kill()
                                game.player = p
                                for e in enemy_group:
                                    e.target = game.player

                            else:
                                unlock_button.text.text = "NOT ENOUGH POINTS"
                                unlock_button.text.update()
                                unlock_button.text.text = "Unlock " + game.selected_ship.node.tag + " - " + str(game.selected_ship.points_cost)

                        screen.blit(unlock_button.image, unlock_button.rect)
                        screen.blit(unlock_button.text.image, unlock_button.text.rect)
                        screen.blit(unlock_all_button.image, unlock_all_button.rect)
                        screen.blit(unlock_all_button.text.image, unlock_all_button.text.rect)

                    else:
                        select_button.update()
                        upgrade_button.update()
                        if select_button.activate:
                            if game.player.type == game.selected_ship:
                                select_button.text.text = "Already Selected!"
                                select_button.text.update()
                                select_button.text.text = "Select"
                            elif game.player.hp > game.player.type.max_health/2:
                                if game.player.type.max_shield and not game.player.shield_active:
                                    select_button.text.text = "Your ship must be in better condition to switch!"
                                    select_button.text.update()
                                    select_button.text.text = "Select"
                                else:
                                    bars_list = [game.player.ammo_1_bar, game.player.hp_bar]
                                    if game.player.type.max_shield:
                                        bars_list.append(game.player.shield_bar)
                                    if game.player.type.attack_2:
                                        bars_list.append(game.player.ammo_2_bar)
                                        if game.player.type.attack_3:
                                            bars_list.append(game.player.ammo_3_bar)
                                    for b in bars_list:
                                        if b.text:
                                            b.text.kill()
                                        b.kill()
                                    for b in bullet_group:
                                        b.kill()
                                    for a in ally_group:
                                        a.kill()
                                    p = Ship(game.selected_ship, game.player.rect.centerx, game.player.rect.centery)
                                    ship_group.add(p)
                                    p.hp = (game.player.hp / (game.player.type.max_health * 2 ** (
                                                game.player.type.level - 1))) * p.type.max_health * 2 ** (
                                                       p.type.level - 1)
                                    if p.type.max_shield and game.player.type.max_shield:
                                        p.shield = game.player.shield / (game.player.type.max_shield * 2 ** (
                                                    game.player.type.level - 1)) * p.type.max_shield * 2 ** (
                                                                                     p.type.level - 1)
                                    p.ammo_1 = 0
                                    p.ammo_2 = 0
                                    p.ammo_3 = 0
                                    game.player.kill()
                                    game.player = p
                                    for e in enemy_group:
                                        e.target = game.player
                                    select_button.text.text = "Selected!"
                                    select_button.text.update()
                                    select_button.text.text = "Select"
                            else:
                                select_button.text.text = "Your ship must be in better condition to switch!"
                                select_button.text.update()
                                select_button.text.text = "Select"
                        if upgrade_button.activate:
                            if game.selected_ship.level < game.selected_ship.start_level + 2:
                                if game.points >= round(game.selected_ship.points_cost * 2 ** (game.selected_ship.level + 1 - game.selected_ship.start_level)):
                                    game.points -= round(game.selected_ship.points_cost * 2 ** (game.selected_ship.level + 1 - game.selected_ship.start_level))
                                    game.selected_ship.level += 0.5
                                    for b in bar_group:
                                        if not b.screen:
                                            if b.text:
                                                b.text.kill()
                                            b.kill()
                                    for b in bullet_group:
                                        b.kill()
                                    for a in ally_group:
                                        a.kill()
                                    p = Ship(game.selected_ship, game.player.rect.centerx, game.player.rect.centery)
                                    ship_group.add(p)
                                    game.player.kill()
                                    game.player = p
                                    for e in enemy_group:
                                        e.target = game.player
                                    if game.selected_ship.level < game.selected_ship.start_level + 2:
                                        upgrade_button.text.text = "Upgraded!"
                                        upgrade_button.text.update()
                                        upgrade_button.text.text = "Upgrade " + game.selected_ship.node.tag + " - " + str(round(game.selected_ship.points_cost * 2 ** (game.selected_ship.level + 1 - game.selected_ship.start_level)))
                                    else:
                                        upgrade_button.text.text = "Maxed!"
                                        upgrade_button.text.update()
                                        upgrade_button.text.text = "MAX LEVEL"

                                else:
                                    upgrade_button.text.text = "NOT ENOUGH POINTS"
                                    upgrade_button.text.update()
                                    upgrade_button.text.text = "Upgrade " + game.selected_ship.node.tag + " - " + str(round(game.selected_ship.points_cost * 2 ** (game.selected_ship.level + 1 - game.selected_ship.start_level)))
                            else:
                                upgrade_button.text.text = "CANNOT UPGRADE FURTHER"
                                upgrade_button.text.update()
                                upgrade_button.text.text = "MAX LEVEL"
                        screen.blit(select_button.image, select_button.rect)
                        screen.blit(upgrade_button.image, upgrade_button.rect)
                        screen.blit(select_button.text.image, select_button.text.rect)
                        screen.blit(upgrade_button.text.image, upgrade_button.text.rect)
                    blit_text(tech_tree_popup.image, popup_text, (10, WIN_H/4), pygame.font.SysFont("Monospace", int(250/math.sqrt(len(popup_text))), bold=True), screen)
                    level_display_bar.length = game.selected_ship.level * 25
                    for b in bar_group:
                        if b.screen == "tech_tree_popup":
                            b.update(screen)
                            if b.text:
                                b.text.update()
                    for b in bar_group:
                        if b.screen == "tech_tree_popup":
                            screen.blit(b.image, b.rect)
                            if b.markers >= 0:
                                for a in range(b.markers):
                                    pygame.draw.line(screen, GREEN,
                                                     (b.max_length * (a + 1) // b.markers + b.rect.left, b.rect.bottom),
                                                     (b.max_length * (a + 1) // b.markers + b.rect.left, b.rect.top), 2)
                            if b.text:
                                screen.blit(b.text.image, b.text.rect)

                pygame.display.flip()
                clock.tick(fps)

            else:
                if game.tech_tree_popup:
                    game.tech_tree_popup = False
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        sys.exit()
                if pygame.key.get_pressed()[pygame.K_e]:
                    if not e_down:
                        game.tech_tree_open = True
                        e_down = True
                else:
                    e_down = False

                a = random.randrange(1, (len(enemy_group.sprites()))**2 * round(2000/game.time**(1/3)) + 2)
                if a == 1:
                    b = random.randrange(0, len(enemies_list))
                    t = Enemy(enemies_list[b], (random.randrange(camera.rect.left, camera.rect.right), 0), camera, game, scaling=game.time/4000)
                    enemy_group.add(t)

                a = random.randrange(1, 100//star_spawnrate)
                if a == 1:
                    s = Background_Star(False)
                    star_group.add(s)
                screen.fill(BLACK)

                for s in ship_group:
                    s.update(camera, screen)
                    if s.alive == False:
                        game.play = False
                        game.menu = True
                        s.kill()
                        for b in bullet_group:
                            b.kill()
                        for e in enemy_group:
                            e.kill()
                        for e in enemy_bullet_group:
                            e.kill()
                        for e in enemy_indicator_group:
                            e.kill()
                        for b in bar_group:
                            b.kill()
                        for t in text_group:
                            t.kill()
                        for a in ally_group:
                            a.kill()
                        for node in tech_tree.all_nodes():
                            node.data.level = False
                        basic_ship.level = 1
                        game.points = 0
                fps_text.text = "FPS: " + str(round(clock.get_fps(), 2))
                points_text.text = "Points: " + str(game.points)
                for b in bullet_group:
                    b.update(camera)
                for e in enemy_group:
                    e.update(screen, camera)
                for a in ally_group:
                    a.update(screen, camera, game.player)
                for e in enemy_bullet_group:
                    e.update()
                for e in enemy_indicator_group:
                    e.update(camera)
                for b in bar_group:
                    b.update(screen)
                for t in text_group:
                    t.update()
                for b in button_group:
                    b.update()
                for s in star_group:
                    s.update()
                camera.update(game.player)
                for s in star_group:
                    screen.blit(s.image, s.apply_camera(camera))

                for s in ship_group:
                    blit_rot_center(s.image, math.degrees(s.direction), camera.apply(s.rect), screen)
                for a in ally_group:
                    blit_rot_center(a.image, math.degrees(a.direction), camera.apply(a.rect), screen)
                for b in bullet_group:
                    blit_rot_center(b.image, math.degrees(b.direction), camera.apply(b.rect), screen)
                for e in enemy_group:
                    blit_rot_center(e.image, math.degrees(e.direction), camera.apply(e.rect), screen)
                for e in enemy_bullet_group:
                    blit_rot_center(e.image, math.degrees(e.direction), camera.apply(e.rect), screen)
                for e in enemy_indicator_group:
                    if e.display:
                        color = e.image.get_at((0, 0))
                        e.image.set_colorkey(color)
                        blit_rot_center(e.image, math.degrees(e.direction), camera.apply(e.rect), screen)
                for b in bar_group:
                    if not b.screen:
                        screen.blit(b.image, b.rect)
                        if b.markers >= 0:
                            for a in range(b.markers):
                                pygame.draw.line(screen, GREEN, (b.max_length * (a + 1) // b.markers + b.rect.left, b.rect.bottom), (b.max_length * (a + 1) // b.markers + b.rect.left, b.rect.top), 2)
                        if b.text:
                            screen.blit(b.text.image, b.text.rect)
                screen.blit(fps_text.image, fps_text.rect)
                screen.blit(points_text.image, points_text.rect)
                screen.blit(scaling_text.image, scaling_text.rect)
                for b in button_group:
                    if (b.screen == None or b.screen == "play") and b.display:
                        screen.blit(b.image, b.rect)
                pygame.display.flip()
                clock.tick(fps)
                if inf_points or pygame.key.get_pressed()[pygame.K_g]:
                    game.points += 100

def generate_tech_tree():
    a = WIN_H/(tech_tree.depth()*4)
    b = WIN_W/(len(tech_tree.leaves())*4)
    if a > b:
        button_size = b
    else:
        button_size = a
    passed_list = []
    x_pos_dict = {}
    i = 1
    node = tech_tree.get_node(tech_tree.root)
    while len(x_pos_dict) < len(tech_tree.leaves()):
        if tech_tree.children(node.identifier):
            not_passed = False
            for n in tech_tree.children(node.identifier):
                if n.identifier not in passed_list and not not_passed:
                    not_passed = True
                    node = n
                    passed_list.append(n.identifier)
            if not not_passed:
                node = tech_tree.parent(node.identifier)
        else:
            b = Button(WIN_W * i / (len(tech_tree.leaves()) + 1),
                       WIN_H - WIN_H * (tech_tree.depth(node) + 1) / (tech_tree.depth() + 2), button_size, button_size,
                       screen="tech_tree", image=pygame.transform.scale(pygame.transform.rotate(node.data.image, 90), (button_size*node.data.image.get_rect().height/node.data.image.get_rect().width, button_size)),
                       hover_image=pygame.transform.scale(pygame.transform.rotate(node.data.image, 90), (button_size*node.data.image.get_rect().height/node.data.image.get_rect().width, button_size)), data=node)
            button_group.add(b)
            node.data.button = b
            x_pos_dict[node.identifier] = WIN_W * i / (len(tech_tree.leaves()) + 1)
            i += 1
            node = tech_tree.parent(node.identifier)

    nodes_list = tech_tree.all_nodes()
    nodes_list.reverse()
    for node in nodes_list:
        if tech_tree.children(node.identifier):
            num_children = 0
            total_x = 0
            for child in tech_tree.children(node.identifier):
                total_x += x_pos_dict[child.identifier]
                num_children += 1
            b = Button(total_x / num_children,
                       WIN_H - WIN_H * (tech_tree.depth(node) + 1) / (tech_tree.depth() + 2),
                       button_size, button_size, screen="tech_tree", image=pygame.transform.scale(pygame.transform.rotate(node.data.image, 90), (button_size*node.data.image.get_rect().height/node.data.image.get_rect().width, button_size)),
                       hover_image=pygame.transform.scale(pygame.transform.rotate(node.data.image, 90), (button_size*node.data.image.get_rect().height/node.data.image.get_rect().width, button_size)), data=node)
            button_group.add(b)
            node.data.button = b

            x_pos_dict[node.identifier] = total_x / num_children


if __name__ == "__main__":
    button_group = pygame.sprite.Group()
    ship_group = pygame.sprite.Group()
    ally_group = pygame.sprite.Group()
    bullet_group = pygame.sprite.Group()
    enemy_group = pygame.sprite.Group()
    enemy_bullet_group = pygame.sprite.Group()
    enemy_indicator_group = pygame.sprite.Group()
    bar_group = pygame.sprite.Group()
    text_group = pygame.sprite.Group()
    star_group = pygame.sprite.Group()
    game = Game()

    main()