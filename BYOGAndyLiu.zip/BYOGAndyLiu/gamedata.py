import pygame
from treelib import *

WIN_W = 600
WIN_H = 800

WHITE = (255, 255, 255)
LIGHTER_GREY = (200, 200, 200)
LIGHT_GREY = (150, 150, 150)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
YELLOW = (255, 255, 0)
GREEN = (0, 255, 0)
DARK_GREEN = (0, 200, 0)
BLUE = (0, 0, 255)
LIGHT_BLUE = (150, 150, 255)
ORANGE = (200, 150, 0)

star_spawnrate = 8

fps = 60

default_image = pygame.transform.rotate(pygame.image.load("image/RaidenMK2Raiden2.png"), 270)

inf_points = False

class Ship_Type(pygame.sprite.Sprite):
    def __init__(self, image, health, shield, shield_def, speed, turn_speed, width, height, attack1, attack2, attack3, points, start_level, description_text=""):
        pygame.sprite.Sprite.__init__(self)
        self.image = image
        self.max_health = float(health[0:health.find(";")])
        self.health_regen = float(health[health.find(";") + 1: -1])
        if shield:
            self.max_shield = float(shield[0:shield.find(";")])
            self.shield_regen = float(shield[shield.find(";") + 1: -1])
            self.shield_def_abs = float(shield_def[0:shield_def.find(";")])
            self.shield_def_mult = float(shield_def[shield_def.find(";") + 1 : -1])
        else:
            self.max_shield = 0
        self.speed = speed
        self.width = width
        self.height = height
        self.attack_1 = attack1
        self.attack_2 = attack2
        self.attack_3 = attack3
        self.turn_speed = turn_speed
        self.level = False
        self.points_cost = points
        self.node = None
        self.button = None
        self.start_level = start_level
        self.description_text = description_text

class Ally_Type(pygame.sprite.Sprite):
    def __init__(self, health, speed, width, height, attack, behavior, image=None):
        pygame.sprite.Sprite.__init__(self)
        self.health = health
        self.speed = speed
        self.width = width
        self.height = height
        self.attack = attack
        self.behavior = behavior
        self.image = image


class Attack_Type(pygame.sprite.Sprite):
    def __init__(self, bullet_type, volley, firerate, cooldown, spread, random_spread, type, shots, aim):
        pygame.sprite.Sprite.__init__(self)
        self.bullet = bullet_type
        self.volley = volley
        self.firerate = firerate
        self.cooldown = cooldown
        self.spread = spread
        self.random_spread = random_spread
        self.type = type
        self.shots = shots
        self.aim = aim

class Bullet_Type(pygame.sprite.Sprite):
    def __init__(self, speed, width, height, damage, accel, homing, delay, spread, image=None):
        pygame.sprite.Sprite.__init__(self)
        self.speed = speed
        self.width = width
        self.height = height
        self.accel = accel
        self.homing_speed = homing
        self.delay = delay
        self.spread = spread
        self.damage = damage
        self.image = image

class Enemy_Type(pygame.sprite.Sprite):
    def __init__(self, health, speed, width, height, enemy_attack, behavior, image=None):
        pygame.sprite.Sprite.__init__(self)
        self.health = health
        self.speed = speed
        self.width = width
        self.height = height
        self.attack = enemy_attack
        self.behavior = behavior
        self.image = image
        #"strafe_._": move to target y amd shoot at player while moving to random target coords within radius
        #"snipe_;_": strafe within radius of target y
        #"dive_": move at a steep angle down the screen, attack, and fly offa
        #"bomb_": move to bottom of screen to shoot, then move back up

class Enemy_Attack(pygame.sprite.Sprite):
    def __init__(self, bullet_type, volley, firerate, cooldown, spread, random_spread, aim_shot, type, shots):
        pygame.sprite.Sprite.__init__(self)
        self.bullet = bullet_type
        self.volley = volley
        self.firerate = firerate
        self.cooldown = cooldown
        self.spread = spread
        self.random_spread = random_spread
        self.aim_shot = aim_shot #True = aims every shot number = turns n degrees speed in between shooting
        self.type = type
        self.shots = shots
        #"regular" = regular
        #"shotgun_" = shotgun _ shells, must add extra _ at end, spread = total angle of spread shot
        #"spiral" = shoots in circle around self, turns spread degrees, spread = angular dist between shots
        #"laser" = draws line to deal dmg, spread = width of beam
        #"sides_" = shoots pairs of shots from either side, angle intervals of spread away from front


class Enemy_Bullet_Type(pygame.sprite.Sprite):
    def __init__(self, speed, width, height, damage, accel, homing, delay, spread, image=None):
        pygame.sprite.Sprite.__init__(self)
        self.speed = speed
        self.width = width
        self.height = height
        self.damage = damage
        self.accel = accel
        self.homing_speed = homing
        self.delay = delay
        self.spread = spread
        self.image = image

enemies_list = []

# enemy_bullet_regular = Enemy_Bullet_Type(8, 5, 5, 5, False, 0, 0, 0)
# enemy_attack_regular = Enemy_Attack(enemy_bullet_regular, 4, 10, 90, 0, 2, True, "regular", 1)
# enemy_type_regular = Enemy_Type(10, 0.1, WIN_W/25, WIN_H/24, enemy_attack_regular, "strafe" + str(WIN_H//4) + ";200_")
#
# enemy_bullet_slow = Enemy_Bullet_Type(5, 5, 5, 5, False, 0, 0, 0)
# enemy_attack_shotgun = Enemy_Attack(enemy_bullet_regular, 3, 10, 60, 20, 5, True, "shotgun5_", 1)
# enemy_type_shotgun = Enemy_Type(10, 0.25, WIN_W/25, WIN_H/24, enemy_attack_shotgun, "diveplayer200_")
#
# enemy_attack_spiral = Enemy_Attack(enemy_bullet_slow, 30, 60, 420, 24, 0, False, "spiral", 1)
# enemy_type_spiral = Enemy_Type(10, 0.3, WIN_W/25, WIN_H/30, enemy_attack_spiral, "bomb" + str(WIN_H//5) + ";100_")
#
# enemy_bullet_rocket = Enemy_Bullet_Type(0.3, 5, 5, 5, "7;5_", True, "90;60_", 5)
# enemy_attack_rocket = Enemy_Attack(enemy_bullet_rocket, 8, 60, 360, 0, 30, True, "sides1_", 1)
# enemy_type_rocket = Enemy_Type(10, 0.1, WIN_W/25, WIN_H/24, enemy_attack_rocket, "snipe" + str(WIN_H//4) + ";100_")
#
# enemy_attack_laser = Enemy_Attack(None, 240, 20, 240, 8, 0, 20, "laser1_", 1)
# enemy_type_laser = Enemy_Type(10, 0.1, WIN_W/25, WIN_H/24, enemy_attack_laser, "snipe" + str(WIN_H//4) + ";50_")
#
# enemy_bullet_missile = Enemy_Bullet_Type("0.35;0.98_", 5, 5, 5, 8, 720, "40;0_", 0)
# enemy_attack_missile = Enemy_Attack(enemy_bullet_missile, 2, 1, 480, 25, 0, True, "sides2_", 1)
# enemy_type_missile = Enemy_Type(10, 0.1, WIN_W/25, WIN_H/24, enemy_attack_missile, "snipe" + str(WIN_H//5) + ";100_")
#
# enemy_attack_backline = Enemy_Attack(enemy_bullet_regular, 4, 5, 180, 105, 20, True, "shotgun2_", 3)
# enemy_type_backline = Enemy_Type(10, 0.3, WIN_W/25, WIN_H/24, enemy_attack_backline, "snipe" + str(WIN_H//8) + ";50_")

enemy_bullet_regular = Enemy_Bullet_Type(4, 7, 7, 5, False, 0, 0, 0, image=pygame.image.load("image/enemy_bullet_red.png"))
enemy_attack_regular = Enemy_Attack(enemy_bullet_regular, 5, 10, 50, 0, 3, True, "regular", 1)
enemy_type_regular = Enemy_Type(11, 0.1, 32, 40, enemy_attack_regular, "strafe" + str(WIN_H//3) + ";150_",  image=pygame.image.load("image/regular_enemy.png"))
enemies_list.append(enemy_type_regular)

enemy_bullet_light = Enemy_Bullet_Type(5, 4, 4, 3, False, 0, 0, 0, image=pygame.image.load("image/enemy_bullet_yellow.png"))
enemy_attack_spray = Enemy_Attack(enemy_bullet_light, 8, 10, 110, 0, 50, True, "regular", 2)
enemy_type_spray = Enemy_Type(7, 0.1, 30, 35, enemy_attack_spray, "snipe" + str(WIN_H//5) + ";100_", image=pygame.image.load("image/spray_enemy.png"))
enemies_list.append(enemy_type_spray)

enemy_attack_shotgun = Enemy_Attack(enemy_bullet_regular, 3, 3, 150, 60, 0, True, "shotgun3_", 1)
enemy_type_shotgun = Enemy_Type(5, 0.2, 30, 30, enemy_attack_shotgun, "bomb" + str(WIN_H//5) + ";200_", image=pygame.image.load("image/shotgun_enemy.png"))
enemies_list.append(enemy_type_shotgun)

enemy_attack_shotgun2 = Enemy_Attack(enemy_bullet_light, 4, 4, 120, 85, 0, True, "shotgun6_", 1)
enemy_type_shotgun2 = Enemy_Type(9, 0.1, 39, 39, enemy_attack_shotgun2, "strafe" + str(WIN_H//3) + ";200_",  image=pygame.image.load("image/shotgun_enemy2.png"))
enemies_list.append(enemy_type_shotgun2)

enemy_rocket = Enemy_Bullet_Type(0.4, 18, 10, 6, "1;1_", 0, "20;5_", 0, image=pygame.image.load("image/enemy_rocket.png"))
enemy_attack_rocket = Enemy_Attack(enemy_rocket, 4, 8, 140, 0, 20, True, "regular", 1)
enemy_type_rocket = Enemy_Type(10, 0.2, 32, 32, enemy_attack_rocket, "snipe" + str(WIN_H//10) + ";150_", image=pygame.image.load("image/rocket_enemy.png"))
enemies_list.append(enemy_type_rocket)

enemy_attack_laser = Enemy_Attack(None, 150, 5, 180, 8, 0, 20, "laser2_", 1)
enemy_type_laser = Enemy_Type(10, 0.1, 45, 33, enemy_attack_laser, "snipe" + str(WIN_H//4) + ";50_", image=pygame.image.load("image/laser_enemy.png"))
enemies_list.append(enemy_type_laser)

enemy_attack_spiral = Enemy_Attack(enemy_bullet_regular, 30, 60, 200, 24, 0, False, "spiral", 1)
enemy_type_spiral = Enemy_Type(8, 0.3, 39, 39, enemy_attack_spiral, "strafe" + str(WIN_H//3) + ";250_", image=pygame.image.load("image/spiral_enemy.png"))
enemies_list.append(enemy_type_spiral)

enemy_mine = Enemy_Bullet_Type(0.4, 17, 17, 4, False, 0, 0, 0, image=pygame.image.load("image/mine.png"))
enemy_attack_mine = Enemy_Attack(enemy_mine, 2, 2, 90, 0, 60, False, "regular", 2)
enemy_type_mine = Enemy_Type(6, 0.1, 38, 30, enemy_attack_mine, "dive300_", image=pygame.image.load("image/mine_layer.png"))
enemies_list.append(enemy_type_mine)



enemy_rocket2 = Enemy_Bullet_Type(0.4, 18, 10, 6, "5;2_", True, "60;0_", 0, image=pygame.image.load("image/enemy_rocket.png"))

enemy_rocket_amongus = Enemy_Bullet_Type(0.4, 18, 10, 999, "15;14_", True, "150;60_", 0, image=pygame.image.load("image/enemy_rocket.png"))
enemy_attack_amongus = Enemy_Attack(enemy_rocket_amongus, 20, 60, 300, 0, 30, True, "sides1_", 30)
enemy_type_amongus = Enemy_Type(99999, 0.5, 30, 36, enemy_attack_amongus, "strafe" + str(WIN_H//2) + ";200_", image=pygame.image.load("image/amongus_enemy.png"))
#enemies_list.append(enemy_type_amongus)

# enemy_bullet_rocket = Enemy_Bullet_Type(0.3, 5, 5, 5, "7;5_", True, "90;60_", 5)
# enemy_attack_rocket = Enemy_Attack(enemy_bullet_rocket, 8, 60, 360, 0, 30, True, "sides1_", 1)
# enemy_type_rocket = Enemy_Type(10, 0.1, WIN_W/25, WIN_H/24, enemy_attack_rocket, "snipe" + str(WIN_H//4) + ";100_")

#
# ally_bullet_regular = Enemy_Bullet_Type(15, 5, 5, 3, False, 0, 0, 0)
# ally_attack_regular = Enemy_Attack(ally_bullet_regular, 12, 30, 90, 0, 5, True, "regular", 1)
# ally_type_regular = Ally_Type(10, 0.2, WIN_W/25, WIN_H/24, ally_attack_regular, "follow" + str(WIN_H*3//4) + ";200_")
#
# ally_attack_turret = Enemy_Attack(ally_bullet_regular, 3000, 8, 240, 0, 10, True, "regular", 1)
# ally_type_turret = Ally_Type(25, 0, WIN_W/25, WIN_H/24, ally_attack_turret, "follow" + str(WIN_H*3//4) + ";200_")
#
# ally_attack_laser = Enemy_Attack(None, 60, 20, 60, 8, 0, 20, "laser3_", 1)
# ally_type_laser = Enemy_Type(10, 0.1, WIN_W/25, WIN_H/24, ally_attack_laser, "follow" + str(WIN_H*3//4) + ";50_")
#
# nate_bullet_regular = Enemy_Bullet_Type(20, 5, 5, 99, False, 0, 0, 0)
# nate_attack_regular = Enemy_Attack(nate_bullet_regular, 3, 10, 90, 45, 0, True, "shotgun9_", 1)
# ally_type_nate = Ally_Type(999, 0.3, WIN_W/25, WIN_H/24, nate_attack_regular, "bomb" + str(WIN_H//5) + ";50_")

none_bullet = Bullet_Type(0, 0, 0, 0, False, 0, 0, 0)
none_attack = Enemy_Attack(none_bullet, 0, 0.000001, 99999, 0, 0, False, "regular", 0)
shield_ally = Ally_Type(10, 0.2, 65, 65, none_attack, "follow" + str(WIN_H*3//4) + ";0_", image=pygame.image.load("image/shield.png"))

basic_light_bullet = Bullet_Type(20, 9, 9, 2, False, 0, 0, 0, image=pygame.image.load("image/basic_bullet_image.png"))

drone_attack = Enemy_Attack(basic_light_bullet, 3, 3, 60, 0, 3, True, "regular", 1)
drone = Ally_Type(8, 0.3, 23, 23, drone_attack, "follow;100_", image=pygame.image.load("image/drone2.png"))

drone_attack_weak = Enemy_Attack(basic_light_bullet, 2, 3, 90, 0, 3, True, "regular", 1)
drone_weak = Ally_Type(5, 0.3, 20, 20, drone_attack_weak, "follow;150_", image=pygame.image.load("image/drone2.png"))

spam_drone_attack = Enemy_Attack(basic_light_bullet, 2, 4, 30, 0, 7, True, "regular", 1)
spam_drone = Ally_Type(3, 0.4, 18, 18, spam_drone_attack, "follow;250_", image=pygame.image.load("image/drone.png"))

drone_attack_shotgun = Enemy_Attack(basic_light_bullet, 1, 60, 180, 30, 0, True, "shotgun3_", 1)
drone_shotgun = Ally_Type(4, 0.4, 22, 20, drone_attack_shotgun, "bomb" + str(WIN_H//5) + ";50_", image=pygame.image.load("image/shotgun_drone.png"))

krish_drone_bullet = Bullet_Type(15, 16, 16, 4, False, 0, 0, 0, image=pygame.image.load("image/krish_drone.png"))
krish_drone_attack = Enemy_Attack(krish_drone_bullet, 1, 0.01, 30, 360, 0, True, "shotgun25_", 1)
krish_drone = Ally_Type(1, 0.8, 16, 16, krish_drone_attack, "diveplayer1_", image=pygame.image.load("image/krish_drone.png"))

drone_rocket = Bullet_Type("0.4;0.99_", 10, 10, 3, "2;0_", True, "20;0_", 10, image=pygame.image.load("image/rocket.png"))
drone_attack_rocket = enemy_attack_rocket
drone_attack_rocket.bullet = drone_rocket
drone_attack_rocket.volley = 3
rocket_drone = Ally_Type(2, 0.2, 20, 26, drone_attack_rocket, "follow;300_", image=pygame.image.load("image/rocket_drone.png"))
tech_tree = Tree()

# bullet_type = Bullet_Type(15, 5, 5, 1, False, 0, 0, 0)
# player_attack_regular = Attack_Type(bullet_type, 1, 60, 5, 0, 10, "regular", 1, True)
# ship_type = Ship_Type(default_image, "10;0.01_", "10;0.01_", "0;1_", 8, 720, WIN_W/25, WIN_H/24, player_attack_regular, None, None, 50, 1, description_text="""The basic starter ship
# Equipped with a light machine gun, effective at short-medium range""")
# ship_type.level = 1
# tech_tree.create_node("ship_type", "ship_type", data=ship_type)
# ship_type.node = tech_tree.get_node("ship_type")
#
# bullet_type_slow = Bullet_Type(8, 6, 6, 2, False, 0, 0, 0)
# player_attack_shotgun = Attack_Type(bullet_type_slow, 5, 6, 80, 45, 0, "shotgun9_", 1, True)
# ship_type_shotgun = Ship_Type(default_image, "10;0.01_", "10;0.01_", "0;1_", 8, 720, WIN_W/25, WIN_H/24, player_attack_shotgun, None, None, 60, 1)
# tech_tree.create_node("ship_type_shotgun", "ship_type_shotgun", parent="ship_type", data=ship_type_shotgun)
# ship_type_shotgun.node = tech_tree.get_node("ship_type_shotgun")
#
# bullet_type_rocket = Bullet_Type(0.3, 6, 6, 4, "3;1_", True, "30;0_", 0)
# player_attack_rocket = Attack_Type(bullet_type_rocket, 8, 15, 60, 0, 0, "sides1_", 1, True)
# ship_type_rocket = Ship_Type(default_image, "10;0.01_", "10;0.01_", "0;1_", 10, 720, WIN_W/25, WIN_H/24, player_attack_rocket, None, None, 150, 1)
# tech_tree.create_node("ship_type_rocket", "ship_type_rocket", parent="ship_type", data=ship_type_rocket)
# ship_type_rocket.node = tech_tree.get_node("ship_type_rocket")
#
# bullet_type_missile = Bullet_Type("0.35;0.98_", 6, 6, 2, "5;3_", 720, "30;0_", 0)
# player_attack_missile = Attack_Type(bullet_type_missile, 3, 4, 90, 20, 0, "sides2_", 1, True)
# ship_type_missile = Ship_Type(default_image, "10;0.01_", "10;0.01_", "0;1_", 6, 60, WIN_W/25, WIN_H/24, player_attack_missile, None, None, 350, 1)
# tech_tree.create_node("ship_type_missile", "ship_type_missile", parent="ship_type_rocket", data=ship_type_missile)
# ship_type_missile.node = tech_tree.get_node("ship_type_missile")
#
# player_attack_laser = Attack_Type(None, 420, 90, 1.5, 8, 0, "laser1_", 1, False)
# ship_type_laser = Ship_Type(default_image, "15;0.02_", "30;0.03_", "0.5;0.5_", 5, 60, WIN_W/25, WIN_H/24, player_attack_laser, player_attack_regular, None, 500, 1)
# tech_tree.create_node("ship_type_laser", "ship_type_laser", parent="ship_type_shotgun", data=ship_type_laser)
# ship_type_laser.node = tech_tree.get_node("ship_type_laser")
#
#
# missile_type_nate = Bullet_Type("7;0.7_", 6, 6, 99, "5;3_", 720, "30;0_", 0)
# nate_attack_missile = Attack_Type(missile_type_nate, 999, 60, 1, 60, 0, "sides1_", 3, True)
# nate_attack_laser = Attack_Type(None, 99999, 20 , 0.01, 15, 0, "laser10_", 1, False)
# nate_attack_spawn = Attack_Type(ally_type_nate, 10, 3, 30, 0, 0, "spawn10_", 1, True)
# ship_type_nate = Ship_Type(default_image, "999;99_", "999;99_", "0;1_", 9, 720, WIN_W/25, WIN_H/24, nate_attack_laser, nate_attack_missile, nate_attack_spawn, 0, 1)
# tech_tree.create_node("ship_type_nate", "ship_type_nate", parent="ship_type", data=ship_type_nate)
# ship_type_nate.node = tech_tree.get_node("ship_type_nate")
#
# player_attack_build = Attack_Type(ally_type_turret, 2, 3, 90, 0, 0, "spawn3_", 1, True)
# ship_type_builder = Ship_Type(default_image, "10;0.01_", "10;0.01_", "0;1_", 4, 60, WIN_W/25, WIN_H/24, player_attack_build, player_attack_regular, None, 400, 1)
# tech_tree.create_node("ship_type_builder", "ship_type_builder", parent="ship_type_shotgun", data=ship_type_builder)
# ship_type_builder.node = tech_tree.get_node("ship_type_builder")
#
# player_attack_spawn = Attack_Type(ally_type_regular, 2, 3, 90, 0, 0, "spawn4_", 1, True)
# ship_type_carrier = Ship_Type(default_image, "10;0.01_", "10;0.01_", "0;1_", 4, 60, WIN_W/25, WIN_H/24, player_attack_spawn, player_attack_regular, None, 500, 1)
# tech_tree.create_node("ship_type_carrier", "ship_type_carrier", parent="ship_type_builder", data=ship_type_carrier)
# ship_type_carrier.node = tech_tree.get_node("ship_type_carrier")
#
# player_attack_spawn2 = Attack_Type(ally_type_laser, 2, 3, 90, 0, 0, "spawn4_", 1, True)
# ship_type_carrier2 = Ship_Type(default_image, "10;0.01_", "10;0.01_", "0;1_", 4, 60, WIN_W/25, WIN_H/24, player_attack_spawn2, player_attack_regular, None, 500, 1)
# tech_tree.create_node("ship_type_carrier2", "ship_type_carrier2", parent="ship_type_builder", data=ship_type_carrier2)
# ship_type_carrier2.node = tech_tree.get_node("ship_type_carrier2")

basic_bullet = Bullet_Type(15, 10, 10, 3, False, 0, 0, 0, image=pygame.image.load("image/basic_bullet_image.png"))
basic_attack = Attack_Type(basic_bullet, 6, 3, 20, 0, 2, "regular", 1, True)
basic_ship = Ship_Type(pygame.transform.rotate(pygame.image.load("image/basic_ship_image.png"), -90), "11;0.01_", False, None, 6, 720, 27, 36, basic_attack, None, None, 20, 1, description_text="""The basic starter ship.
Someone had the bright idea of strapping a pistol to an evacuation ship.""")
basic_ship.level = 1
tech_tree.create_node("basic ship", "basic_ship", data=basic_ship)
basic_ship.node = tech_tree.get_node("basic_ship")

no_attack = Attack_Type(none_bullet, 1, 0.0001, 99999, 0, 0, "regular", 0, True)
challenge_ship = Ship_Type(pygame.transform.rotate(pygame.image.load("image/basic_ship_image.png"), -90), "0.001;0_", False, None, 6, 720, 27, 36, no_attack, None, None, 0, 0, description_text=""""Your game is too easy"                                                                           """)
tech_tree.create_node("Challenge Ship", "challenge_ship", data=challenge_ship, parent="basic_ship")
challenge_ship.node = tech_tree.get_node("challenge_ship")

basic_mg_attack = Attack_Type(basic_light_bullet, 24, 10, 10, 0, 9, "regular", 1, True)
basic_mg_ship = Ship_Type(pygame.image.load("image/basic_mg_ship_image.png"), "8;0.01_", False, None, 5, 720, 15, 36, basic_mg_attack, None, None, 50, 1, description_text="""Another hastily putten-together evacuation ship, but with a machine gun this time.
Now we're getting somewhere.""")
tech_tree.create_node("assault ship", "basic_mg_ship", data=basic_mg_ship, parent="basic_ship")
basic_mg_ship.node = tech_tree.get_node("basic_mg_ship")

side_mg_attack = Attack_Type(basic_light_bullet, 20, 8, 15, 0, 8, "regular", 1, True)

basic_shotgun_attack = Attack_Type(basic_bullet, 2, 3, 30, 40, 10, "shotgun5_", 1, False)
basic_shotgun_ship = Ship_Type(pygame.image.load("image/basic_shotgun_ship_image.png"), "12;0.02_", False, None, 6, 240, 15, 36, basic_shotgun_attack, None, None, 120, 2, description_text="""Continuing the tradition of refusing to use a proper armed space ship, now we have shotguns!.""")
tech_tree.create_node("Shotgun ship", "basic_shotgun_ship", data=basic_shotgun_ship, parent="basic_mg_ship")
basic_shotgun_ship.node = tech_tree.get_node("basic_shotgun_ship")

space_bullet = Bullet_Type(20, 11, 11, 4, False, 0, 0, 0, image=pygame.image.load("image/space_bullet_image.png"))
basic_space_attack = Attack_Type(space_bullet, 4, 3, 30, 0, 0, "regular", 1, True)
basic_space_ship = Ship_Type(pygame.image.load("image/basic_space_ship_image.png"), "10;0.02_", False, None, 7, 720, 21, 36, basic_space_attack, None, None, 100, 2, description_text="""Finally, a space-worthy vessel.
Designed to be mass-produced when new waves of colonizers were organized.
Relatively underpowered, but the start of much more progress.""")
tech_tree.create_node("'Frontier Horizons' Mk I", "basic_space_ship", data=basic_space_ship, parent="basic_ship")
basic_space_ship.node = tech_tree.get_node("basic_space_ship")

basic_space_attack2 = Attack_Type(space_bullet, 4, 6, 45, 0, 1, "regular", 1, True)
double_space_ship = Ship_Type(pygame.image.load("image/double_space_ship.png"), "10;0.02_", False, None, 7, 720, 21, 36, basic_space_attack2, basic_space_attack2, None, 170, 2, description_text="""A small ship with more firepower and better regenerative capabilities.
Redesigned to be hardier after the first waves of colonizers became waves of tragic deaths.
Features two guns!""")
tech_tree.create_node("'Frontier Horizons' Mk II", "double_space_ship", data=double_space_ship, parent="basic_space_ship")
double_space_ship.node = tech_tree.get_node("double_space_ship")

heavy_space_bullet = Bullet_Type(20, 12, 12, 10, False, 0, 0, 0, image=pygame.image.load("image/space_bullet_image.png"))
basic_heavy_attack = Attack_Type(heavy_space_bullet, 3, 2, 60, 0, 0, "regular", 1, True)
basic_heavy_ship = Ship_Type(pygame.image.load("image/basic_heavy_ship.png"), "10;0.01_", "10;0.02_", "0;0.5_", 5, 240, 21, 36, basic_heavy_attack, None, None, 310, 3, description_text="""A more durable vessel designed to withstand the dangers of exploring the galaxy
Has armor that blocks 50% of incoming damage.
Features a heavy cannon for self-defense.""")
tech_tree.create_node("'Seafarer' V", "basic_heavy_ship", data=basic_heavy_ship, parent="basic_space_ship")
basic_heavy_ship.node = tech_tree.get_node("basic_heavy_ship")

heavy_space_bullet2 = Bullet_Type(40, 15, 15, 20, False, 0, 0, 0, image=pygame.image.load("image/space_bullet_image.png"))
heavy_attack = Attack_Type(heavy_space_bullet2, 1, 1, 60, 0, 0, "regular", 1, False)
railgun_ship = Ship_Type(pygame.image.load("image/railgun_ship.png"), "15;0.02_", "20;0.04_", "0;0.5_", 4, 150, 21, 36, heavy_attack, basic_attack, None, 210, 3, description_text="""Has a big gun.
A really big gun.
Also a smaller gun.""")
tech_tree.create_node("Projectile Accelerator Prototype", "railgun_ship", data=railgun_ship, parent="basic_heavy_ship")
railgun_ship.node = tech_tree.get_node("railgun_ship")

railgun_laser_attack = Attack_Type(None, 60, 50, 4, 15, 0, "laser10_", 1, False)
railgun_laser_ship = Ship_Type(pygame.image.load("image/railgun_laser_ship.png"), "15;0.01_", "20;0.02_", "0;0.5_", 3, 120, 21, 36, railgun_laser_attack, basic_space_attack2, None, 120, 4, description_text="""Sports a heavy railgun that charges up and can penetrate multiple targets.""")
tech_tree.create_node("'Annihilation' Class Warship", "railgun_laser_ship", data=railgun_laser_ship, parent="railgun_ship")
railgun_laser_ship.node = tech_tree.get_node("railgun_laser_ship")

laser_attack = Attack_Type(None, 300, 80, 2, 4, 0, "laser0.8_", 1, False)
laser_ship = Ship_Type(pygame.image.load("image/laser_ship.png"), "15;0.01_", "10;0.03_", "0;0.5_", 5, 150, WIN_W/25, WIN_H/24, laser_attack, None, None, 200, 3, description_text="""A mining ship, outfitted with a heavy laser to drill through large asteroids.
The laser takes some time to charge up before it can deal damage.
Slow and bulky.""")
tech_tree.create_node("'Prosperity' Mining Ship", "laser_ship", parent="basic_heavy_ship", data=laser_ship)
laser_ship.node = tech_tree.get_node("laser_ship")

laser_attack2 = Attack_Type(None, 360, 60, 1, 6, 0, "laser1.2_", 1, False)
laser_ship2 = Ship_Type(pygame.image.load("image/laser_ship2.png"), "25;0.03_", "30;0.05_", "0;0.5_", 4, 90, WIN_W/25, WIN_H/24, laser_attack2, basic_space_attack2, None, 350, 4, description_text="""A well-rounded retrofitted mining ship, designed to hold its own in competitive mining spaces.
Features a better laser, better defense, and a secondary gun that rotates independently.
All of this is taken from the previous designs speed capabilities""")
tech_tree.create_node("'Prosperity II' Mining Platform", "laser_ship2", parent="laser_ship", data=laser_ship2)
laser_ship2.node = tech_tree.get_node("laser_ship2")

spray_space_bullet = Bullet_Type(13, 11, 11, 6, False, 0, 0, 0, image=pygame.image.load("image/large_space_bullet.png"))
spray_attack = Attack_Type(spray_space_bullet, 40, 10, 5, 0, 8, "regular", 1, True)
platform_ship = Ship_Type(pygame.image.load("image/platform.png"), "15;0.01_", "20;0.05_", "4;0.4_", 2, 100, 50, 50, spray_attack, basic_heavy_attack, None, 500, 5, description_text="""An orbital defense platform.
Heavy weaponry and impressive defense.
Shields subtract a certain amount of damage from every incoming hit, providing protection against smaller projectiles.
Moves slowly.""")
tech_tree.create_node("Star Shield Orbital Defense Platform", "platform_ship", parent="basic_heavy_ship", data=platform_ship)
platform_ship.node = tech_tree.get_node("platform_ship")

rocket = Bullet_Type("0.4;0.99_", 10, 10, 6, "2;0_", True, "20;0_", 0, image=pygame.image.load("image/rocket.png"))
light_rocket_attack = Attack_Type(rocket, 2, 3, 50, 0, 0, "sides1_", 1, False)

platform_ship2 = Ship_Type(pygame.image.load("image/platform_ship2.png"), "15;0.01_", "20;0.05_", "4;0.4_", 2, 90, 50, 50, spray_attack, basic_heavy_attack, light_rocket_attack, 500, 6, description_text="""An orbital defense platform.
Heavy weaponry and impressive defense.
Shields subtract a certain amount of damage from every incoming hit, providing protection against smaller projectiles.
Moves slowly.""")
tech_tree.create_node("Orbital Defensive Array", "platform_ship2", parent="platform_ship", data=platform_ship2)
platform_ship2.node = tech_tree.get_node("platform_ship2")

light_spray_bullet = Bullet_Type(15, 9, 9, 3, False, 0, 0, 0, image=pygame.image.load("image/large_space_bullet.png"))
space_mg_attack = Attack_Type(light_spray_bullet, 1, 60, 10, 0, 15, "regular", 1, False)
basic_light_ship = Ship_Type(pygame.image.load("image/basic_light_ship.png"), "6;0.03_", "0.1;0.05_", "0;1_", 8, 720, 14, 24, space_mg_attack, None, None, 200, 3, description_text="""A fast, light ship, to be controlled by pilots skilled enough to dodge projectiles in close-quarters.
Has a fast regenerating shield that allows the ship to sustain occasional hits but not sustained fire.""")
tech_tree.create_node("Fighter M-1", "basic_light_ship", parent="double_space_ship", data=basic_light_ship)
basic_light_ship.node = tech_tree.get_node("basic_light_ship")

double_mg_attack = Attack_Type(light_spray_bullet, 1, 60, 10, 0, 10, "regular", 2, False)
double_light_ship = Ship_Type(pygame.image.load("image/double_light_ship.png"), "5;0.03_", "0.1;0.05_", "0;1_", 9, 720, 14, 24, double_mg_attack, None, None, 300, 4, description_text="""A fast, light ship, to be controlled by pilots skilled enough to dodge projectiles in close-quarters.
Has a fast regenerating shield that allows the ship to sustain occasional hits but not sustained fire.""")
tech_tree.create_node("Fighter M-2", "double_light_ship", parent="basic_light_ship", data=double_light_ship)
double_light_ship.node = tech_tree.get_node("double_light_ship")

spray_attack2 = Attack_Type(light_spray_bullet, 6, 30, 50, 0, 14, "regular", 1, False)
double_fighter_ship = Ship_Type(pygame.image.load("image/double_fighter_ship.png"), "5;0.04_", "0.1;0.05_", "0;1_", 9, 720, 22, 24, spray_attack2, spray_attack2, None, 400, 5, description_text="""A fast, light ship, to be controlled by pilots skilled enough to dodge projectiles in close-quarters.
Has a fast regenerating shield that allows the ship to sustain occasional hits but not sustained fire.""")
tech_tree.create_node("Fighter M-3", "double_fighter_ship", parent="double_light_ship", data=double_fighter_ship)
double_fighter_ship.node = tech_tree.get_node("double_fighter_ship")

space_shotgun_attack = Attack_Type(light_spray_bullet, 1, 60, 20, 0, 25, "regular", 3, False)
shotgun_ship = Ship_Type(pygame.image.load("image/shotgun_ship.png"), "7;0.03_", "0.1;0.1_", "0;1_", 8, 720, 18, 26, space_shotgun_attack, None, None, 200, 4, description_text="""Equipped with a shotgun to further increase its close-range capabilities.""")
tech_tree.create_node("Fighter S-1", "shotgun_ship", parent="basic_light_ship", data=shotgun_ship)
shotgun_ship.node = tech_tree.get_node("shotgun_ship")

rocket_attack = Attack_Type(rocket, 6, 2, 40, 0, 0, "sides1_", 1, True)

rocket_ship = Ship_Type(pygame.image.load("image/rocket_ship.png"), "12;0.02_", "20;0.03_", "1;0.5_", 4, 240, 33, 39, rocket_attack, side_mg_attack, None, 800, 4, description_text="""A high-end space vessel equipped with rockets that pack a punch.""")
tech_tree.create_node("4", "rocket_ship", data=rocket_ship, parent="basic_heavy_ship")
rocket_ship.node = tech_tree.get_node("rocket_ship")

missile = Bullet_Type("0.35;0.98_", 13, 14, 8, "5;3_", 720, "30;0_", 0, image=pygame.image.load("image/missile.png"))
missile_attack = Attack_Type(missile, 2, 3, 90, 0, 0, "sides1_", 1, True)
rocket_missile_ship = Ship_Type(pygame.image.load("image/rocket_missile_ship.png"), "14;0.02_", "20;0.03_", "2;0.5_", 4, 240, 33, 39, rocket_attack, missile_attack, None, 2000, 5, description_text="""A heavy warship equipped with both high-damage rockets and lower damage homing missiles""")
tech_tree.create_node("Destroyer I", "rocket_missile_ship", data=rocket_missile_ship, parent="rocket_ship")
rocket_missile_ship.node = tech_tree.get_node("rocket_missile_ship")

shield_attack = Attack_Type(shield_ally, 1, 1, 120, 0, 0, "spawn2_", 1, True)
shield_ship = Ship_Type(pygame.image.load("image/shield_ship.png"), "14;0.02_", "20;0.03_", "2;0.5_", 4, 240, 33, 39, rocket_attack, shield_attack, None, 1500, 5, description_text="""A heavy warship equipped with both high-damage rockets and lower damage homing missiles""")
tech_tree.create_node("Destroyer I", "shield_ship", data=shield_ship, parent="rocket_ship")
shield_ship.node = tech_tree.get_node("shield_ship")

spawn_drone = Attack_Type(drone, 1, 1, 300, 0, 0, "spawn1_", 1, True)
carrier = Ship_Type(pygame.image.load("image/carrier.png"), "14;0.01_", "18;0.02_", "1;0.5_", 3, 120, 36, 45, basic_space_attack, spawn_drone, None, 500, 4, description_text="""An innovative ship that features the ability to release an independent drone that will automatically fight for you.""")
tech_tree.create_node("Carrier A-1", "carrier", parent="basic_heavy_ship", data=carrier)
carrier.node = tech_tree.get_node("carrier")

spawn_drone_weak = Attack_Type(drone_weak, 1, 1, 220, 0, 0, "spawn3_", 1, True)
carrier2 = Ship_Type(pygame.image.load("image/carrier2.png"), "13;0.02_", "16;0.03_", "1;0.4_", 3, 100, 36, 45, basic_space_attack, spawn_drone_weak, None, 800, 5, description_text="""Is able to spawn 3 weaker, independent drones.""")
tech_tree.create_node("Carrier A-2", "carrier2", parent="carrier", data=carrier2)
carrier2.node = tech_tree.get_node("carrier2")

spawn_drone_spam = Attack_Type(spam_drone, 2, 2, 180, 0, 0, "spawn3_", 1, True)

battle_carrier = Ship_Type(pygame.image.load("image/battle_carrier.png"), "12;0.05_", "15;0.05_", "2;0.5_", 4, 160, 39, 54, rocket_attack, spawn_drone_spam, None, 900, 6, description_text="""A powerful warship that trades off drone capability to self-preservation and combat buffs.""")
tech_tree.create_node("Carrier B-1", "battle_carrier", parent="carrier2", data=battle_carrier)
battle_carrier.node = tech_tree.get_node("battle_carrier")

spawn_drone_shotgun = Attack_Type(drone_shotgun, 1, 2, 190, 0, 0, "spawn3_", 1, True)
spawn_drone_rocket = Attack_Type(rocket_drone, 1, 2, 230, 0, 0, "spawn3_", 1, True)
spawn_drone_krish = Attack_Type(krish_drone, 2, 3, 60, 0, 0, "spawn5_", 1, True)
carrier3 = Ship_Type(pygame.image.load("image/carrier3.png"), "14;0.02_", "18;0.03_", "3;0.3_", 2, 80, 40, 60, spawn_drone_shotgun, spawn_drone_rocket, spawn_drone_krish, 1000, 7, description_text="""A heavy carrier that carries multiple types of drones.""")
tech_tree.create_node("Carrier A-3", "carrier3", parent="carrier2", data=carrier3)
carrier3.node = tech_tree.get_node("carrier3")